#!/usr/bin/env python3
"""Apply a pre-verified DEB sequence through APT after one polkit authentication."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
import update_core as core


def load_plan(path, expected_uid=None):
    path = Path(path)
    if path.is_symlink() or not path.is_absolute() or path.name != 'plan.json':
        raise core.UpdateError('Invalid installation plan')
    work = path.parent
    if not work.name.startswith('lazilyfax-update-') or work.is_symlink():
        raise core.UpdateError('Invalid update workspace')
    if expected_uid is not None and (path.stat().st_uid != expected_uid or work.stat().st_uid != expected_uid):
        raise core.UpdateError('Update workspace owner mismatch')
    if path.stat().st_size > 256 * 1024: raise core.UpdateError('Plan too large')
    plan = json.loads(path.read_text(encoding='utf-8'))
    if plan.get('format') != 'lazilyfax-install-plan-v1': raise core.UpdateError('Invalid plan format')
    steps = plan.get('steps')
    if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
        raise core.UpdateError('Invalid installation steps')
    version = core.valid_version(plan.get('base_version'))
    for step in steps:
        if not isinstance(step, dict) or step.get('from_version') != version:
            raise core.UpdateError('Discontinuous installation plan')
        target = core.valid_version(step.get('to_version'))
        if not core.newer(target, version): raise core.UpdateError('Installation would not move forward')
        deb = Path(step['deb'])
        if not deb.is_absolute() or deb.is_symlink() or deb.suffix != '.deb':
            raise core.UpdateError('Invalid DEB path')
        rel = deb.relative_to(work)
        p = work
        for part in rel.parts:
            p = p / part
            if p.is_symlink(): raise core.UpdateError('Symlink in update path')
        if core.digest(deb.read_bytes()) != step.get('sha256'):
            raise core.UpdateError('Prepared DEB checksum mismatch')
        for field, expected in [('Package','lazilyfax'),('Version',target),('Architecture','amd64')]:
            actual = subprocess.check_output(['dpkg-deb','-f',str(deb),field],text=True).strip()
            if actual != expected: raise core.UpdateError('Prepared DEB identity mismatch')
        version = target
    if version != plan.get('target_version'): raise core.UpdateError('Plan does not reach target')
    return plan


def install_plan(plan, current_version=core.installed_version, runner=subprocess.run, progress=None):
    """A failed stage never starts later stages; a retry uses installed package state."""
    if current_version() != plan['base_version']:
        raise core.UpdateError('Installed version changed. Check for updates again.')
    env = os.environ.copy()
    env['DEBIAN_FRONTEND'] = 'noninteractive'
    for index, step in enumerate(plan['steps'], 1):
        if current_version() != step['from_version']:
            raise core.UpdateError('Installed version does not match next stage')
        if core.digest(Path(step['deb']).read_bytes()) != step['sha256']:
            raise core.UpdateError('Prepared DEB changed before installation')
        if progress: progress(index, len(plan['steps']), step['to_version'])
        result = runner(['/usr/bin/apt-get','install','-y',step['deb']],
                        env=env,stdin=subprocess.DEVNULL,check=False)
        if result.returncode != 0: return result.returncode
        if current_version() != step['to_version']:
            raise core.UpdateError('Installed version does not match completed stage')
    return 0


def main():
    if os.geteuid() != 0: raise core.UpdateError('Administrator authentication is required')
    uid = int(os.environ['PKEXEC_UID'])
    path = Path(sys.argv[1])
    if path.parent.parent != Path(tempfile.gettempdir()):
        raise core.UpdateError('Unexpected update workspace location')
    plan = load_plan(path,uid)
    return install_plan(plan,progress=lambda i,n,v:print(f'LAZILYFAX_STEP {i}/{n} {v}',flush=True))

if __name__ == '__main__':
    try: raise SystemExit(main())
    except Exception as error:
        print('LazilyFAX update: '+str(error),file=sys.stderr)
        raise SystemExit(1)
