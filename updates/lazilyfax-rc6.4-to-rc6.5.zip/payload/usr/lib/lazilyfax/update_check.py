#!/usr/bin/env python3
"""Native update window. Network/build work runs away from the Tk thread."""
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import lifecycle
import language
import update_core as core

COPY = {
 'ja': {'title':'アップデートの確認','checking':'更新情報を確認しています…','latest':'最新の状態です。',
  'available':'更新があります：{version}（{count}段階）','check':'再確認','apply':'ダウンロードして更新','close':'閉じる',
  'preparing':'更新パッチを取得し、インストール用パッケージを準備しています…',
  'step':'更新の準備 {index}/{count}：{version}',
  'confirm':'LazilyFAXの画面を終了して更新します。未保存の内容は保存してください。\n受信待受・通信を停止してから進んでください。\n\n更新しますか？',
  'error':'更新できませんでした','current':'現在の版：{version}',
  'note':'設定・履歴を保持して更新します。適用時に管理者認証が必要です。'},
 'en': {'title':'Check for Updates','checking':'Checking for updates…','latest':'You are up to date.',
  'available':'Update available: {version} ({count} steps)','check':'Check Again','apply':'Download and Update','close':'Close',
  'preparing':'Downloading the patch and preparing the installation package…',
  'step':'Preparing {index}/{count}: {version}',
  'confirm':'LazilyFAX windows will close for the update. Save any changes first.\nStop reception and FAX activity before continuing.\n\nUpdate now?',
  'error':'Could Not Update','current':'Installed version: {version}',
  'note':'Settings and history will be retained. Administrator authentication is required to install.'},
 'ko': {'title':'업데이트 확인','checking':'업데이트 정보를 확인하고 있습니다…','latest':'최신 버전입니다.',
  'available':'업데이트가 있습니다: {version} ({count}단계)','check':'다시 확인','apply':'다운로드 및 업데이트','close':'닫기',
  'preparing':'업데이트 패치를 다운로드하고 설치 패키지를 준비하고 있습니다…',
  'step':'업데이트 준비 {index}/{count}: {version}',
  'confirm':'업데이트를 위해 LazilyFAX 창을 종료합니다. 변경 사항을 먼저 저장해 주세요.\n수신 대기와 통신을 중지한 후 진행해 주세요.\n\n업데이트하시겠습니까?',
  'error':'업데이트할 수 없습니다','current':'설치된 버전: {version}',
  'note':'설정과 기록을 유지하여 업데이트합니다. 설치 시 관리자 인증이 필요합니다.'},
}

class UpdateWindow:
 def __init__(self,root):
  self.root=root
  self.words=COPY.get(language.get_language(),COPY['en'])
  self.current=core.installed_version()
  self.info=None;self.work=None;self.busy=False;self.events=queue.Queue()
  root.title('LazilyFAX — '+self.words['title']);root.geometry('650x310');root.minsize(600,300)
  frame=ttk.Frame(root,padding=22);frame.pack(expand=True,fill='both')
  ttk.Label(frame,text=self.words['title'],font=('Sans',17,'bold')).pack(anchor='w')
  ttk.Label(frame,text=self.words['current'].format(version=self.current)).pack(anchor='w',pady=(10,5))
  self.status=ttk.Label(frame,wraplength=590);self.status.pack(anchor='w',pady=8)
  ttk.Label(frame,text=self.words['note'],wraplength=590).pack(anchor='w',pady=8)
  row=ttk.Frame(frame);row.pack(side='bottom',fill='x')
  self.check_button=ttk.Button(row,text=self.words['check'],command=self.check);self.check_button.pack(side='left')
  self.apply_button=ttk.Button(row,text=self.words['apply'],command=self.apply,state='disabled');self.apply_button.pack(side='left',padx=8)
  self.close_button=ttk.Button(row,text=self.words['close'],command=self.close);self.close_button.pack(side='right')
  root.protocol('WM_DELETE_WINDOW',self.close)
  root.after(100,self.poll);self.check()
 def run(self,kind,operation):
  self.busy=True;self.check_button.configure(state='disabled');self.apply_button.configure(state='disabled')
  def worker():
   try:self.events.put((kind,operation(),None))
   except Exception as error:self.events.put((kind,None,str(error)))
  threading.Thread(target=worker,daemon=True).start()
 def check(self):
  if self.busy:return
  self.info=None;self.status.configure(text=self.words['checking'])
  self.run('check',lambda:core.check_metadata(self.current))
 def apply(self):
  if self.busy or not self.info:return
  if not messagebox.askyesno(self.words['title'],self.words['confirm'],parent=self.root):return
  # A read-only guard first; GUI windows may remain until the download is ready.
  try:
   fd=lifecycle.acquire_activity()
   try:
    active=lifecycle.processes()
    if any(n=='efax' or n in lifecycle.BUSY for n in active.values()):
     raise core.UpdateError('Stop FAX/modem activity before updating.')
   finally:lifecycle.release_activity(fd)
  except Exception as error:
   messagebox.showerror(self.words['error'],str(error),parent=self.root);return
  self.work=Path(tempfile.mkdtemp(prefix='lazilyfax-update-',dir='/tmp'))
  self.status.configure(text=self.words['preparing'])
  self.run('prepare',lambda:core.prepare(self.info,self.current,self.work,
       progress=lambda i,n,v:self.events.put(('progress',(i,n,v),None))))
 def poll(self):
  try:kind,result,error=self.events.get_nowait()
  except queue.Empty:self.root.after(100,self.poll);return
  if kind=='progress':
   i,n,v=result;self.status.configure(text=self.words['step'].format(index=i,count=n,version=v))
   self.root.after(100,self.poll);return
  self.busy=False;self.check_button.configure(state='normal')
  if error:
   self.status.configure(text=self.words['error']+'\n'+error)
  elif kind=='check':
   self.info=result
   self.status.configure(text=self.words['available'].format(version=result['package_version'],count=len(result.get('steps',[])) or 1) if result else self.words['latest'])
   if result:self.apply_button.configure(state='normal')
  else:
   try:
    # Refuse other users and new activity before closing any related idle windows.
    if core.installed_version()!=self.current:raise core.UpdateError('Installed version changed. Check again.')
    for pid in lifecycle.processes():
     if Path('/proc',str(pid)).stat().st_uid!=os.getuid():raise core.UpdateError('Another user is running LazilyFAX.')
    lifecycle.stop_idle(exclude_pid=os.getpid())
    subprocess.Popen(['/usr/bin/python3',str(Path(__file__).with_name('update_install.py')),
                      str(result),str(os.getpid()),language.get_language()],start_new_session=True)
    self.root.destroy();return
   except Exception as error:
    self.status.configure(text=self.words['error']+'\n'+str(error))
  self.root.after(100,self.poll)
 def close(self):
  if self.busy:return
  self.root.destroy()

def main():
 root=tk.Tk()
 try:UpdateWindow(root)
 except Exception as error:
  root.withdraw();messagebox.showerror('LazilyFAX Update',str(error),parent=root);root.destroy();return 1
 root.mainloop();return 0
if __name__=='__main__':raise SystemExit(main())
