"""Download a public delta and rebuild a DEB from a verified installed base.

No installed files are written here. Installation is always delegated to APT.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import time
from urllib.parse import urlsplit
from urllib.request import Request, urlopen, build_opener, HTTPRedirectHandler
import zipfile

METADATA_URL = 'https://raw.githubusercontent.com/lazillywalker/lazilyfax/main/version.json'
FORMAT = 'lazilyfax-delta-v1'
MAX_PATCH = 32 * 1024 * 1024
MAX_PAYLOAD = 128 * 1024 * 1024
EXACT_PATHS = {
    'usr/bin/lazilyfax', 'usr/lib/cgi-bin/faxbook.cgi', 'usr/lib/cgi-bin/faxlog.cgi',
    'usr/share/applications/lazilyfax.desktop', 'usr/share/applications/lazilyfax-pdf.desktop',
    'usr/share/applications/lazilyfax-uninstall.desktop',
    'usr/share/polkit-1/actions/com.lazilysoft.fax.policy',
    'etc/apache2/conf-available/lazilyfax.conf',
}
CONTROL_FILES = {'control','preinst','postinst','prerm','postrm','conffiles','md5sums'}

class UpdateError(Exception):
    pass

def valid_version(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9][A-Za-z0-9.+:~_-]{0,99}', value):
        raise UpdateError('Invalid version')
    return value

def newer(candidate, current):
    valid_version(candidate); valid_version(current)
    return subprocess.run(['dpkg','--compare-versions',candidate,'gt',current], check=False).returncode == 0

def installed_version():
    result = subprocess.run(['dpkg-query','-W','-f=${Status}\n${Version}','lazilyfax'],
                            capture_output=True,text=True,check=False)
    lines = result.stdout.splitlines()
    if result.returncode or len(lines) != 2 or lines[0] != 'install ok installed':
        raise UpdateError('LazilyFAX package is not fully installed')
    return valid_version(lines[1])

def patch_url(url):
    if not isinstance(url,str): raise UpdateError('Invalid download URL')
    parts = urlsplit(url)
    if (parts.scheme != 'https' or parts.netloc != 'raw.githubusercontent.com' or
        not re.fullmatch(r'/lazillywalker/lazilyfax/main/updates/[A-Za-z0-9._-]+\.zip',parts.path)
        or parts.query or parts.fragment):
        raise UpdateError('Update URL is not in the official repository')
    return url

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise UpdateError('Unexpected update redirect')

def fetch(url, limit):
    opener = build_opener(NoRedirect())
    request = Request(url, headers={'User-Agent':'LazilyFAX-Updater/1','Cache-Control':'no-cache'})
    with opener.open(request, timeout=20) as response:
        data = response.read(limit + 1)
    if len(data) > limit: raise UpdateError('Update download too large')
    return data

def select_route(catalog, current, latest):
    """Choose a complete, forward-only path before downloading anything."""
    from collections import deque
    valid_version(current); valid_version(latest)
    if not isinstance(catalog, list) or len(catalog) > 1000:
        raise UpdateError('Invalid update catalog')
    edges = {}
    seen = set()
    for entry in catalog:
        if not isinstance(entry, dict): raise UpdateError('Invalid update step')
        source = valid_version(entry.get('base_version'))
        target = valid_version(entry.get('package_version'))
        if not newer(target, source): raise UpdateError('Update steps must move forward')
        pair = (source, target)
        if pair in seen: raise UpdateError('Duplicate update step')
        seen.add(pair)
        if entry.get('format') != FORMAT: raise UpdateError('Unsupported update format')
        patch_url(entry.get('download_url'))
        if not isinstance(entry.get('sha256'), str) or not re.fullmatch('[0-9a-f]{64}', entry['sha256']):
            raise UpdateError('Invalid update checksum')
        edges.setdefault(source, []).append(dict(entry))
    pending = deque([(current, [])])
    visited = {current}
    while pending:
        version, route = pending.popleft()
        if version == latest: return route
        for edge in edges.get(version, []):
            target = edge['package_version']
            if target not in visited:
                visited.add(target)
                pending.append((target, route + [edge]))
    raise UpdateError('No complete update path from this version. No update was applied.')


def check_metadata(current, fetcher=fetch):
    info = json.loads(fetcher(METADATA_URL+'?check='+str(time.time_ns()),64*1024).decode('utf-8'))
    if not isinstance(info,dict) or info.get('product') != 'LazilyFAX':
        raise UpdateError('Invalid update metadata')
    if info.get('update_available') is False:
        return None
    if info.get('update_available') is not True:
        raise UpdateError('Invalid update availability')
    if 'patches' in info:
        target = valid_version(info.get('latest_package_version'))
        if not newer(target, current): return None
        steps = select_route(info['patches'], current, target)
        return {'product':'LazilyFAX', 'package_version':target, 'steps':steps}
    # Read the first-generation single-step metadata as well.
    target = valid_version(info.get('package_version'))
    if not newer(target,current): return None
    if info.get('format') != FORMAT: raise UpdateError('Unsupported update format')
    bases = info.get('base_versions')
    if not isinstance(bases,list) or current not in bases:
        raise UpdateError('This update requires a different base version')
    patch_url(info.get('download_url'))
    if not isinstance(info.get('sha256'),str) or not re.fullmatch('[0-9a-f]{64}',info['sha256']):
        raise UpdateError('Invalid update checksum')
    return info

def safe_path(value, control=False):
    if not isinstance(value,str) or not value: raise UpdateError('Invalid patch path')
    parts = PurePosixPath(value)
    if parts.is_absolute() or '..' in parts.parts or str(parts) != value:
        raise UpdateError('Unsafe patch path')
    if control:
        if value not in CONTROL_FILES: raise UpdateError('Unsupported control file')
    elif not (value in EXACT_PATHS or value.startswith('usr/lib/lazilyfax/') or
              value.startswith('usr/share/doc/lazilyfax/')):
        raise UpdateError('Patch path outside LazilyFAX')
    return value

def checked_file(root, rel):
    p = Path(root)
    for part in PurePosixPath(rel).parts:
        p = p/part
        if p.is_symlink(): raise UpdateError('Symlink in package path: '+rel)
    if not p.is_file(): raise UpdateError('Missing base file: '+rel)
    return p

def digest(data): return hashlib.sha256(data).hexdigest()

def entries(rows, control=False):
    if not isinstance(rows,list) or len(rows)>4000: raise UpdateError('Invalid file list')
    result = {}
    for row in rows:
        if not isinstance(row,dict): raise UpdateError('Invalid file entry')
        rel = safe_path(row.get('path'),control)
        mode = row.get('mode')
        if rel in result or mode not in (0o644,0o755) or not re.fullmatch('[0-9a-f]{64}',str(row.get('sha256'))):
            raise UpdateError('Invalid file attributes')
        result[rel] = row
    return result

def rebuild_patch(archive, info, current, workspace, installed_root=Path('/')):
    """Validate all bytes and reconstruct a full package in a private workspace."""
    if digest(archive) != info['sha256']: raise UpdateError('Patch checksum mismatch')
    work = Path(workspace)
    stage = work/'package'
    if stage.exists(): raise UpdateError('Package workspace already exists')
    import io
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        names = z.namelist()
        if (len(names)!=len(set(names)) or len(names)>8000 or
            sum(i.file_size for i in z.infolist())>MAX_PAYLOAD):
            raise UpdateError('Invalid patch archive')
        if 'manifest.json' not in names: raise UpdateError('Missing patch manifest')
        if z.getinfo('manifest.json').file_size>2*1024*1024: raise UpdateError('Manifest too large')
        manifest = json.loads(z.read('manifest.json'))
        if (manifest.get('format') != FORMAT or manifest.get('base_version') != current or
            manifest.get('target_version') != info['package_version']):
            raise UpdateError('Patch version mismatch')
        base = entries(manifest.get('base_files'))
        target = entries(manifest.get('target_files'))
        control = entries(manifest.get('control_files'),True)
        if not {'control','preinst','postinst','prerm','postrm','md5sums'} <= set(control):
            raise UpdateError('Incomplete package control files')
        expected = {'manifest.json'} | {'control/'+p for p in control}
        changed = {p for p in target if p not in base or base[p]['sha256']!=target[p]['sha256']}
        expected |= {'payload/'+p for p in changed}
        if set(names)!=expected: raise UpdateError('Unexpected archive entries')
        # Refuse a modified installed base, including files being replaced.
        for rel,row in base.items():
            if digest(checked_file(installed_root,rel).read_bytes())!=row['sha256']:
                raise UpdateError('Installed file differs from update base: '+rel)
        stage.mkdir(mode=0o755)
        for rel,row in target.items():
            data = z.read('payload/'+rel) if rel in changed else checked_file(installed_root,rel).read_bytes()
            if digest(data)!=row['sha256']: raise UpdateError('Payload checksum mismatch: '+rel)
            p = stage/rel
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(data);p.chmod(row['mode'])
        for rel,row in control.items():
            data = z.read('control/'+rel)
            if digest(data)!=row['sha256']: raise UpdateError('Control checksum mismatch')
            p = stage/'DEBIAN'/rel
            p.parent.mkdir(exist_ok=True)
            p.write_bytes(data);p.chmod(row['mode'])
    # Package directory modes must not inherit the user's private umask.
    for directory in [stage, *(p for p in stage.rglob('*') if p.is_dir())]:
        directory.chmod(0o755)
    output = work/('lazilyfax_'+valid_version(info['package_version'])+'_amd64.deb')
    subprocess.run(['dpkg-deb','--root-owner-group','--build',str(stage),str(output)],
                   check=True,capture_output=True,text=True)
    for field,expected in [('Package','lazilyfax'),('Version',info['package_version']),('Architecture','amd64')]:
        value=subprocess.check_output(['dpkg-deb','-f',str(output),field],text=True).strip()
        if value!=expected: raise UpdateError('Rebuilt package identity mismatch')
    return output

def prepare(info, current, workspace, installed_root=Path('/'), fetcher=fetch, progress=None):
    """Prepare every DEB using virtual intermediate installations, without installing."""
    steps = info.get('steps') or [dict(info, base_version=current)]
    if not steps: raise UpdateError('Empty update plan')
    work = Path(workspace)
    plan = {'format':'lazilyfax-install-plan-v1', 'base_version':current,
            'target_version':info['package_version'], 'steps':[]}
    root = Path(installed_root)
    version = current
    for index, edge in enumerate(steps, 1):
        if edge['base_version'] != version or not newer(edge['package_version'], version):
            raise UpdateError('Discontinuous update plan')
        if progress: progress(index, len(steps), edge['package_version'])
        step_dir = work / ('step-' + str(index))
        step_dir.mkdir(mode=0o700)
        data = fetcher(patch_url(edge['download_url']), MAX_PATCH)
        deb = rebuild_patch(data, edge, version, step_dir, root)
        plan['steps'].append({'from_version':version, 'to_version':edge['package_version'],
                              'deb':str(deb.resolve()), 'sha256':digest(deb.read_bytes())})
        root = step_dir / 'package'
        version = edge['package_version']
    if version != info['package_version']: raise UpdateError('Update plan does not reach latest version')
    path = work / 'plan.json'
    path.write_text(json.dumps(plan, indent=2)+'\n', encoding='utf-8')
    path.chmod(0o600)
    return path
