"""License-only translations; reads the existing LazilyFAX language setting."""
import json
from pathlib import Path
CATALOG = json.loads(Path(__file__).with_name('license_translations.json').read_text(encoding='utf-8'))

def selected_language():
    try:
        import language
        code = language.get_language()
        return code if code in CATALOG else 'en'
    except (OSError, ImportError):
        return 'en'

def text(key, code=None, **values):
    return CATALOG.get(code or selected_language(), CATALOG['en'])[key].format(**values)
