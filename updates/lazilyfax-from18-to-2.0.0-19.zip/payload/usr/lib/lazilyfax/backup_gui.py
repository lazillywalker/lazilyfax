#!/usr/bin/env python3
"""Unprivileged native backup/restore screen. All copy/restore I/O is data-only."""
from pathlib import Path
import os
import errno
import queue
import shutil
import subprocess
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
import backup_core as core
import lifecycle
try:
    from language import t
except OSError:
    # Recovery can be opened before a new desktop account has data access.
    from lang_en import TEXT
    def t(key):return TEXT.get(key,key)
from ui_theme import apply_theme

BACKEND=Path('/usr/lib/lazilyfax/backup_backend.py')


def error_text(error):
    if isinstance(error,PermissionError):return t('backup_destination_denied').format(path=error.filename or '')
    if isinstance(error,core.BackupError):return t(error.code)+'\n'+error.detail
    return str(error)


def publish_backup(temporary, target):
    """Publish under a new name exclusively, including concurrent saves.

    Hard links publish the already verified complete file atomically. File
    systems without hard links use exclusive creation and remove failed copies.
    """
    for index in range(100000):
        candidate = target if index == 0 else target.with_name(
            f'{target.stem}_{index:03d}{target.suffix}')
        try:
            try:
                os.link(temporary, candidate)
            except OSError as error:
                if error.errno not in (errno.EPERM, errno.EOPNOTSUPP, errno.EXDEV, errno.ENOSYS):
                    raise
                fd = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                try:
                    with os.fdopen(fd, 'wb') as output, temporary.open('rb') as source:
                        shutil.copyfileobj(source, output)
                        output.flush();os.fsync(output.fileno())
                except BaseException:
                    candidate.unlink(missing_ok=True)
                    raise
            core.fsync_dir(candidate.parent)
            return candidate
        except FileExistsError:
            continue
    raise core.BackupError('backup_failed', 'Too many backup files with the same name.')


import license_backup
import license_i18n

class BackupWindow:
    def __init__(self,root):
        self.root=root;self.busy=False;self.events=queue.Queue();self.selected=None;self.directory=Path.home()
        apply_theme(root)
        style=ttk.Style(root)
        style.configure('Backup.TFrame',background='#FFFFFF')
        style.configure('Backup.TLabel',background='#FFFFFF',foreground='#334155',font=('Sans',10))
        root.title('LazilyFAX - '+t('backup_title'));
        width=max(620,min(720,root.winfo_screenwidth()-80))
        height=max(520,min(660,root.winfo_screenheight()-100))
        root.geometry(f'{width}x{height}');root.minsize(min(680,width),min(560,height))
        frame=ttk.Frame(root,padding=(12,8),style='Backup.TFrame');frame.pack(fill='both',expand=True)
        frame.columnconfigure(0,weight=1);frame.rowconfigure(7,weight=1)
        ttk.Label(frame,text=t('backup_title'),font=('Sans',16,'bold'),style='Backup.TLabel').grid(row=0,column=0,sticky='w')
        for index,key in enumerate(['backup_intro','backup_note','backup_private','backup_limit'],1):
            ttk.Label(frame,text=t(key),wraplength=640,style='Backup.TLabel').grid(row=index,column=0,sticky='w',pady=(5,0))
        actions=ttk.Frame(frame,style='Backup.TFrame');actions.grid(row=5,column=0,sticky='ew',pady=(8,6))
        action_style=dict(bg='#2563A6',fg='#FFFFFF',activebackground='#1D4F85',activeforeground='#FFFFFF',relief='flat',bd=0,padx=16,cursor='hand2',font=('Sans',10))
        self.create_button=tk.Button(actions,text=t('backup_create'),command=self.create,**action_style)
        self.create_button.pack(side='left',ipady=6)
        self.restore_button=tk.Button(actions,text=t('backup_restore'),command=self.restore,**action_style)
        self.restore_button.pack(side='right',ipady=6)
        self.progress=ttk.Progressbar(frame,mode='indeterminate');self.progress.grid(row=6,column=0,sticky='ew')
        self.status=tk.StringVar(value='')
        self.details=ScrolledText(frame,wrap='word',height=3,state='disabled',font=('Sans',10),relief='solid',bd=1)
        self.details.grid(row=7,column=0,sticky='nsew',pady=6)
        self.status.trace_add('write',self.show_status)
        row=ttk.Frame(frame,style='Backup.TFrame');row.grid(row=8,column=0,sticky='ew')
        row.columnconfigure(0,weight=1);row.columnconfigure(1,weight=1)
        self.recover_button=ttk.Button(row,text=t('backup_recover'),command=self.recover);self.recover_button.grid(row=0,column=0,columnspan=2,sticky='w',pady=(0,4))
        self.start_button=ttk.Button(row,text=t('backup_start'),command=self.start);self.start_button.grid(row=1,column=0,sticky='w')
        self.close_button=ttk.Button(row,text=t('backup_close'),command=root.destroy);self.close_button.grid(row=1,column=1,sticky='e')
        license_row=ttk.Frame(frame,style='Backup.TFrame');license_row.grid(row=9,column=0,sticky='ew',pady=(8,0))
        self.license_buttons=[]
        for restore,key in ((False,'license_export'),(True,'license_restore')):
            button=ttk.Button(license_row,text=license_i18n.text(key),command=lambda restoring=restore:license_backup.dialog(self.root,restoring))
            button.pack(anchor='w',pady=2)
            self.license_buttons.append(button)
        self.buttons=[self.create_button,self.restore_button,self.recover_button,self.start_button,self.close_button,*self.license_buttons]
        root.protocol('WM_DELETE_WINDOW',self.close);root.after(100,self.poll)

    def show_status(self,*_):
        self.details.configure(state='normal');self.details.delete('1.0','end')
        self.details.insert('end',self.status.get());self.details.configure(state='disabled')

    def run(self,operation,cleanup=None):
        if self.busy:return
        self.busy=True;self.status.set(t('backup_working'));self.progress.start(12)
        for button in self.buttons:button.configure(state='disabled')
        def worker():
            try:
                lifecycle.stop_idle(exclude_pid=os.getpid())
                self.events.put((True,operation()))
            except Exception as error:self.events.put((False,error_text(error)))
            finally:
                if cleanup:cleanup()
        threading.Thread(target=worker,daemon=True).start()

    def helper(self,args,*,stdin=None,stdout=subprocess.PIPE):
        proc=subprocess.run(['/usr/bin/pkexec',str(BACKEND),*args],stdin=stdin,stdout=stdout,stderr=subprocess.PIPE,check=False)
        if proc.returncode:
            text=proc.stderr.decode('utf-8',errors='replace')[-4096:]
            code=next((line for line in text.splitlines() if line.startswith('backup_')),None)
            if not code:code='backup_auth' if proc.returncode in (126,127) else 'backup_failed'
            raise core.BackupError(code,text)
        return proc

    def create(self):
        selected=filedialog.asksaveasfilename(parent=self.root,title=t('backup_destination'),initialdir=str(self.directory),initialfile=core.default_name(),confirmoverwrite=False,defaultextension=core.EXTENSION,filetypes=[(t('backup_type'),'*'+core.EXTENSION)])
        if not selected:return
        target=Path(selected).absolute()
        # Check the chosen folder before closing any LazilyFAX windows.
        try:
            fd,name=tempfile.mkstemp(prefix='.lfax-writing-',dir=target.parent)
        except OSError as error:
            messagebox.showerror(t('backup_title'),error_text(error),parent=self.root);return
        except core.BackupError as error:
            messagebox.showerror(t('backup_title'),error_text(error),parent=self.root);return
        temporary=Path(name);out=os.fdopen(fd,'wb')
        self.directory=target.parent
        if not messagebox.askyesno(t('backup_title'),t('backup_confirm'),parent=self.root):
            out.close();temporary.unlink(missing_ok=True);return
        def operation():
            try:
                with out:
                    self.helper(['--backup'],stdout=out);out.flush();os.fsync(out.fileno())
                core.inspect(temporary,verify=True)
                saved=publish_backup(temporary,target)
                return t('backup_done').format(path=saved)
            finally:temporary.unlink(missing_ok=True)
        def cleanup():
            out.close()
            temporary.unlink(missing_ok=True)
        self.run(operation,cleanup=cleanup)

    def restore(self):
        selected=filedialog.askopenfilename(parent=self.root,title=t('backup_choose'),initialdir=str(self.directory),filetypes=[(t('backup_type'),'*'+core.EXTENSION)])
        if not selected:return
        archive=Path(selected).absolute();self.directory=archive.parent
        # Verification/hashing may be substantial; perform it off the Tk thread.
        self.busy=True
        for button in self.buttons:button.configure(state='disabled')
        self.progress.start(12);self.status.set(t('backup_working'))
        def inspect():
            selected_copy=None
            try:
                selected_copy=tempfile.TemporaryDirectory(prefix='lfax-selected-')
                frozen=Path(selected_copy.name)/'selected.lfaxbackup'
                digest=core.freeze_archive(archive,frozen)
                manifest=core.inspect(frozen)
                self.events.put(('preview',(frozen,manifest,digest,selected_copy)))
            except Exception as error:
                if selected_copy:selected_copy.cleanup()
                self.events.put((False,error_text(error)))
        threading.Thread(target=inspect,daemon=True).start()

    def apply_restore(self,archive,manifest,digest,selected_copy):
        summary=t('backup_summary').format(date=manifest['created_at'],version=manifest['package_version'],count=len(manifest['files']),size=f"{sum(r['size'] for r in manifest['files'])/1024**2:.1f} MiB")
        self.status.set(summary)
        if not messagebox.askyesno(t('backup_title'),t('backup_confirm_restore').format(summary=summary),parent=self.root):
            selected_copy.cleanup();return
        def operation():
            try:
                with archive.open('rb') as source:result=self.helper(['--restore',digest],stdin=source)
                return t('backup_restored').format(path=result.stdout.decode('utf-8',errors='replace').strip())
            finally:selected_copy.cleanup()
        self.run(operation)

    def recover(self):
        if messagebox.askyesno(t('backup_title'),t('backup_confirm_recover'),parent=self.root):
            self.run(lambda:(self.helper(['--recover']),t('backup_recovered'))[1])

    def poll(self):
        try:kind,value=self.events.get_nowait()
        except queue.Empty:self.root.after(100,self.poll);return
        self.busy=False;self.progress.stop()
        for button in self.buttons:button.configure(state='normal')
        if kind=='preview':self.apply_restore(*value)
        else:
            self.status.set(value)
            if kind:messagebox.showinfo(t('backup_title'),value,parent=self.root)
            else:messagebox.showerror(t('backup_title'),value,parent=self.root)
        self.root.after(100,self.poll)

    def start(self):
        try:subprocess.Popen(['/usr/bin/lazilyfax'],start_new_session=True)
        except OSError as error:messagebox.showerror(t('backup_title'),str(error),parent=self.root);return
        self.root.destroy()

    def close(self):
        if not self.busy:self.root.destroy()


if __name__=='__main__':
    root=tk.Tk();BackupWindow(root);root.mainloop()
