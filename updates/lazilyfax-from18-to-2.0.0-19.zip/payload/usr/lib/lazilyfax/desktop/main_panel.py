#!/usr/bin/env python3
"""Standalone LazilyFAX shell prototype. No fax processes or data are touched."""

import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_sys.path.insert(0, str(_BootstrapPath(__file__).resolve().parents[1]))
_bootstrap_sys.path.insert(0, str(_BootstrapPath(__file__).resolve().parent))

if __name__ == '__main__':
    import sys as _maintenance_sys
    from pathlib import Path as _MaintenancePath
    _maintenance_sys.path.insert(0, str(_MaintenancePath(__file__).resolve().parents[1]))
    from maintenance import guard_start as _maintenance_guard
    _maintenance_gate = _maintenance_guard(recovery_gui=True)

import argparse
import fcntl
import os
import subprocess
import sys
from pathlib import Path
import socket
import tempfile
import threading
import tkinter as tk
import time
from tkinter import messagebox, ttk

from receive_status import status as receive_status, receiver_running, receiver_mode
import panel_i18n as _L
from support_window import show_support
from wing_indicator import WingIndicator, ReceiveCompletions
from tray_icons import tray_icon_path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from voicemail_ui import show_controls, show_messages
from voicemail_runtime import worker_status

from lang_de import GROUPS as _DE_GROUPS
_L.TABLE.update({'留守番電話': ('Answering machine', '자동응답', _DE_GROUPS['voicemail']['title']), '用件音声確認': ('Recorded messages', '녹음 메시지 확인', _DE_GROUPS['voicemail']['messages'])})

_L.TABLE['ライセンス登録'] = ('License registration', '라이선스 등록', 'Lizenzregistrierung')

APP = 'LazilyFAX'


def runtime_paths():
    base = Path(os.environ.get('XDG_RUNTIME_DIR') or tempfile.gettempdir())
    return base / f'lazilyfax-panel-trial-{os.getuid()}.lock', base / f'lazilyfax-panel-trial-{os.getuid()}.sock'


class SingleInstance:
    def __init__(self, on_open):
        self.lock_path, self.socket_path = runtime_paths()
        self.on_open = on_open
        self.fd = None
        self.server = None
        self.running = True

    def acquire(self):
        self.fd = os.open(self.lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            os.close(self.fd)
            self.fd = None
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                    client.settimeout(1)
                    client.connect(str(self.socket_path))
                    client.sendall(b'OPEN\n')
            except OSError:
                pass
            return False
        try:
            self.socket_path.unlink(missing_ok=True)  # under exclusive instance lock
            self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.server.bind(str(self.socket_path))
            os.chmod(self.socket_path, 0o600)
            self.server.listen(3)
            self.server.settimeout(0.3)
        except Exception:
            self.release()
            raise
        threading.Thread(target=self._listen, daemon=True).start()
        return True

    def _listen(self):
        while self.running:
            try:
                client, _ = self.server.accept()
            except (socket.timeout, OSError):
                continue
            with client:
                try:
                    if client.recv(32).strip() == b'OPEN':
                        self.on_open()
                except OSError:
                    pass

    def release(self):
        self.running = False
        if self.server:
            self.server.close()
            self.server = None
            self.socket_path.unlink(missing_ok=True)
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None


class App:
    def __init__(self, root):
        self.root = root
        _L.title(self.root, APP)
        self.root.geometry('520x530')
        self.root.minsize(390, 500)
        self.closing = False
        self.receiving = False
        self.receive_state = 'stopped'
        self.blink_on = False
        self.receive_panel_proc = None
        self.receive_history_proc = None
        self.tray = None
        self.send_panel = None
        self.glib = None
        self.instance = SingleInstance(lambda: self.root.after(0, self.show))
        self.root.protocol('WM_DELETE_WINDOW', self.hide)
        self._build()

    def _build(self):
        self.root.configure(bg='#FFFFFF')
        style = ttk.Style(self.root)
        style.configure('MainPanel.TFrame', background='#FFFFFF')
        style.configure('MainPanel.TLabel', background='#FFFFFF')
        frame = ttk.Frame(self.root, padding=20,
                          style='MainPanel.TFrame')
        frame.pack(expand=True, fill='both')
        self.wing = WingIndicator(frame)
        self.wing.pack(pady=(0, 16))
        self.completions = ReceiveCompletions()
        voicemail_row = ttk.Frame(frame, style='MainPanel.TFrame')
        voicemail_row.pack(fill='x', pady=(0, 12))
        _L.widget(tk.Button, voicemail_row, text='留守番電話',
                  command=lambda: show_controls(self.root), bg='#E0F1E7', fg='#256748',
                  relief='flat', font=('Sans', 11), cursor='hand2').pack(side='left', expand=True, fill='x', padx=5, ipady=7)
        _L.widget(tk.Button, voicemail_row, text='用件音声確認',
                  command=lambda: show_messages(self.root), bg='#E5ECF4', fg='#334155',
                  relief='flat', font=('Sans', 11), cursor='hand2').pack(side='left', expand=True, fill='x', padx=5, ipady=7)
        # Main action buttons: fixed palette, independent of ttk themes.
        row = ttk.Frame(frame, style='MainPanel.TFrame')
        row.pack(fill='x')

        def colored_button(parent, text, command, bg, fg, hover, font):
            button = _L.widget(tk.Button,
                parent, text=text, command=command,
                bg=bg, fg=fg,
                activebackground=hover, activeforeground=fg,
                font=font, relief='flat', bd=0,
                cursor='hand2', highlightthickness=0
            )
            button.bind('<Enter>', lambda e: button.configure(bg=hover))
            button.bind('<Leave>', lambda e: button.configure(bg=bg))
            return button

        send_column = ttk.Frame(row, style='MainPanel.TFrame')
        send_column.pack(side='left', expand=True, fill='both', padx=5)

        colored_button(
            send_column, 'FAX送信', self.open_send_panel,
            '#2563A6', '#FFFFFF', '#1D4F85',
            ('Sans', 13, 'bold')
        ).pack(expand=True, fill='both')

        receive_column = ttk.Frame(row, style='MainPanel.TFrame')
        receive_column.pack(side='left', expand=True, fill='both', padx=5)

        colored_button(
            receive_column, '送受信履歴の確認',
            self.open_receive_history,
            '#368D69', '#FFFFFF', '#287452',
            ('Sans', 11, 'bold')
        ).pack(fill='x', expand=True, pady=(0, 4))

        colored_button(
            receive_column, 'FAX受信',
            self.open_receive_panel,
            '#E0F1E7', '#256748', '#C4E4D2',
            ('Sans', 10)
        ).pack(fill='x', ipady=1)
        pdf_row = ttk.Frame(frame, style='MainPanel.TFrame')
        pdf_row.pack(fill='x', pady=(10, 0))
        colored_button(
            pdf_row, 'PDF作成', self.open_pdf_tool,
            '#E5ECF4', '#334155', '#D3E1F0',
            ('Sans', 11)
        ).pack(fill='x', padx=5, ipady=5)
        self.state_text = _L.StringVar(value='停止中')
        state_row = ttk.Frame(frame, style='MainPanel.TFrame')
        state_row.pack(pady=16)
        background = '#FFFFFF'
        self.state_indicator = tk.Canvas(state_row, width=20, height=20,
                                         background=background, highlightthickness=0)
        self.state_indicator.pack(side='left', padx=(0, 7))
        self.state_circle = self.state_indicator.create_oval(
            3, 3, 17, 17, fill='#FFFFFF', outline='#64748B', width=1)
        _L.widget(ttk.Label, state_row, textvariable=self.state_text, style='MainPanel.TLabel').pack(side='left')
        bottom = ttk.Frame(frame, style='MainPanel.TFrame')
        bottom.pack(fill='x')
        for title in ('設定', 'マニュアル'):
            callback = {'設定': self.open_settings_panel, 'マニュアル': self.open_manual}[title]
            colored_button(
                bottom, title, callback,
                '#E5ECF4', '#334155', '#D3E1F0',
                ('Sans', 10)
            ).pack(side='left', expand=True, fill='x', padx=3, ipady=3)
        test = ttk.Frame(frame, style='MainPanel.TFrame')
        test.pack(fill='x', pady=13)
        colored_button(
            test, 'パネルを閉じる', self.hide,
            '#E5ECF4', '#334155', '#D3E1F0',
            ('Sans', 10)
        ).pack(side='right', padx=3, ipady=3)

    def open_pdf_tool(self):
        script = Path(__file__).resolve().parents[1] / 'pdf_bundle.py'
        try:
            proc = getattr(self, 'pdf_tool_proc', None)
            if proc is None or proc.poll() is not None:
                self.pdf_tool_proc = subprocess.Popen([sys.executable, str(script)], cwd=str(script.parent), start_new_session=True)
        except OSError as error:
            messagebox.showerror(_L.text('PDF作成'), str(error), parent=self.root)

    def open_send_panel(self):
        """Show the send menu once; feature connections will be added later."""
        if self.send_panel is not None and self.send_panel.winfo_exists():
            self.send_panel.deiconify()
            self.send_panel.lift()
            self.send_panel.focus_force()
            return
        panel = tk.Toplevel(self.root)
        self.send_panel = panel
        _L.title(panel, 'LazilyFAX — FAX送信')
        panel.geometry('420x290')
        panel.minsize(360, 260)
        panel.configure(bg='#FFFFFF')
        frame = ttk.Frame(panel, padding=20, style='MainPanel.TFrame')
        frame.pack(expand=True, fill='both')
        _L.widget(ttk.Label, frame, style='MainPanel.TLabel', text='FAX送信', font=('Sans', 18, 'bold')).pack(anchor='w')
        _L.widget(ttk.Label, frame, style='MainPanel.TLabel', text='使用する機能を選んでください').pack(anchor='w', pady=(4, 14))
        buttons = ttk.Frame(frame, style='MainPanel.TFrame')
        buttons.pack(expand=True, fill='both')
        labels = ('FAX送信', 'FAXビュワー', '電話帳')
        for index, label in enumerate(labels):
            bg, fg, active = ('#2563A6', '#FFFFFF', '#1D4F85') if index == 0 else ('#E5ECF4', '#334155', '#D3E1F0')
            _L.widget(tk.Button, buttons, text=label, bg=bg, fg=fg, activebackground=active, activeforeground=fg, relief='flat', bd=0, highlightthickness=0, cursor='hand2', font=('Sans', 10), command=lambda name=label: self.open_send_feature(name)).grid(row=index // 2, column=index % 2, columnspan=2 if index==2 else 1,
                   padx=5, pady=5, sticky='nsew', ipady=12)
        for index in range(2):
            buttons.columnconfigure(index, weight=1)
            buttons.rowconfigure(index, weight=1)
        _L.widget(tk.Button, frame, text='閉じる', bg='#E5ECF4', fg='#334155', activebackground='#D3E1F0', activeforeground='#334155', relief='flat', bd=0, highlightthickness=0, cursor='hand2', padx=16, pady=6, command=panel.destroy).pack(anchor='e', pady=(12, 0))


    def open_manual(self):
        code = _L.read_language()
        if code not in ('ja', 'en', 'ko', 'de'):
            code = 'en'
        target = Path('/usr/share/doc/lazilyfax') / ('manual_' + code + '.pdf')
        if not target.is_file():
            target = Path('/usr/share/doc/lazilyfax/manual_en.pdf')
        if not target.is_file():
            _L.dialog(messagebox.showerror, 'ファイルが見つかりません',
                      str(target), parent=self.root)
            return
        try:
            subprocess.Popen(['xdg-open', str(target)],
                             stdin=subprocess.DEVNULL, start_new_session=True)
        except OSError as error:
            _L.dialog(messagebox.showerror, '起動できません', str(error),
                      parent=self.root)

    def open_settings_gui(self, name):
        scripts = {
            'ヘッダー設定': 'header_gui.py',
            '言語の設定': 'language_settings.py',
            'FAXモデムの設定': 'modem_check.py',
            'セットアップ確認': 'setup_check.py',
            'アップデートの確認': 'update_check.py',
            'バックアップと復元': 'backup_gui.py',
            'ライセンス登録': 'license_gui.py',
        }
        if name == 'FAXモデムの設定' and receiver_running():
            _L.dialog(messagebox.showinfo, '受信を停止してください', '受信操作パネルから受信を停止してから開いてください。', parent=self.root)
            return

        processes = getattr(self, 'settings_gui_processes', {})
        self.settings_gui_processes = processes
        proc = processes.get(name)
        if proc is not None and proc.poll() is None:
            _L.dialog(messagebox.showinfo, name, '既に起動しています。開いている画面を確認してください。', parent=self.root)
            return

        app_dir = Path('/usr/lib/lazilyfax')
        target = (Path(__file__).resolve().parents[1] / scripts[name]) if name in scripts else app_dir / scripts[name]
        setup = app_dir / 'access_setup.py'
        for required in (target, setup):
            if not required.is_file():
                _L.dialog(messagebox.showerror, 'ファイルが見つかりません', str(required), parent=self.root)
                return

        env = os.environ.copy()
        for key in ('PYTHONPATH', 'PYTHONHOME'):
            env.pop(key, None)
        env['PYTHONNOUSERSITE'] = '1'
        env['PYTHONDONTWRITEBYTECODE'] = '1'

        try:
            check = subprocess.run(
                ['/usr/bin/python3', '-I', str(setup), '--check'],
                cwd=str(app_dir), env=env,
                stdin=subprocess.DEVNULL, timeout=10)
            if check.returncode != 0:
                subprocess.Popen(
                    ['/usr/bin/python3', '-I', str(setup)],
                    cwd=str(app_dir), env=env,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True)
                _L.dialog(messagebox.showinfo, '初期設定', 'アクセス設定を完了してから、もう一度押してください。', parent=self.root)
                return

            processes[name] = subprocess.Popen(
                ['/usr/bin/python3', str(target)],
                cwd=str(app_dir), env=env,
                stdin=subprocess.DEVNULL,
                start_new_session=True)
        except (OSError, subprocess.SubprocessError) as error:
            _L.dialog(messagebox.showerror, '起動できません', str(error), parent=self.root)

    def open_settings_feature(self, name):
        if name in ('言語の設定','ヘッダー設定','FAXモデムの設定','セットアップ確認','アップデートの確認','バックアップと復元','ライセンス登録'):
            self.open_settings_gui(name)


    def open_settings_panel(self):
        panel = getattr(self, 'settings_panel', None)
        if panel is not None and panel.winfo_exists():
            panel.deiconify()
            panel.lift()
            panel.focus_force()
            return

        panel = tk.Toplevel(self.root)
        self.settings_panel = panel
        _L.title(panel, 'LazilyFAX — 設定')
        panel.geometry('440x440')
        panel.minsize(400, 420)

        panel.configure(bg='#FFFFFF')
        frame = ttk.Frame(panel, padding=20, style='MainPanel.TFrame')
        frame.pack(expand=True, fill='both')
        _L.widget(ttk.Label, frame, style='MainPanel.TLabel', text='設定', font=('Sans', 18, 'bold')).pack(anchor='w')
        _L.widget(ttk.Label, frame, style='MainPanel.TLabel', text='設定する項目を選んでください').pack(
            anchor='w', pady=(4, 14))

        buttons = ttk.Frame(frame, style='MainPanel.TFrame')
        buttons.pack(expand=True, fill='both')
        labels = (
            '言語の設定', 'ヘッダー設定',
            'アップデートの確認', 'FAXモデムの設定',
            'セットアップ確認', 'バックアップと復元',
            'ライセンス登録',
        )
        for index, label in enumerate(labels):
            _L.widget(tk.Button, buttons, text=label, bg='#2563A6', fg='#FFFFFF', activebackground='#1D4F85', activeforeground='#FFFFFF', relief='flat', bd=0, highlightthickness=0, cursor='hand2', font=('Sans', 10), command=lambda name=label: self.open_settings_feature(name)).grid(
                row=index // 2, column=index % 2,
                columnspan=1,
                padx=5, pady=5, sticky='nsew', ipady=12)

        for index in range(2):
            buttons.columnconfigure(index, weight=1)
        for index in range(4):
            buttons.rowconfigure(index, weight=1)

        footer = ttk.Frame(frame, style='MainPanel.TFrame')
        footer.pack(fill='x', pady=(12, 0))
        for label, callback in (
            ('閉じる', panel.destroy),
            ('サポート', lambda: show_support(panel, _L.read_language())),
        ):
            _L.widget(tk.Button, footer, text=label, bg='#E5ECF4', fg='#334155', activebackground='#D3E1F0', activeforeground='#334155', relief='flat', bd=0, highlightthickness=0, cursor='hand2', width=10, pady=6, command=callback).pack(
                side='right', padx=(8, 0))

    def open_send_feature(self, name):
        if name in ('FAX通信履歴','FAX送信履歴'):
            return self.open_receive_history()
        app_dir = Path('/usr/lib/lazilyfax')
        urls = {
        }
        try:
            if name in urls:
                subprocess.Popen(
                    ['xdg-open', urls[name]],
                    stdin=subprocess.DEVNULL,
                    start_new_session=True)
                return

            scripts = {
                '電話帳': 'phonebook_gui.py',
                'FAX送信': 'fax_gui.py',
                'FAXビュワー': 'fax_viewer.py',
            }
            if name not in scripts:
                return


            processes = getattr(self, 'send_feature_processes', {})
            self.send_feature_processes = processes
            proc = processes.get(name)
            if proc is not None and proc.poll() is None:
                _L.dialog(messagebox.showinfo, name, '既に起動しています。開いている画面を確認してください。', parent=self.send_panel)
                return

            target = Path(__file__).resolve().parents[1] / scripts[name]
            setup = app_dir / 'access_setup.py'
            for required in (target, setup):
                if not required.is_file():
                    _L.dialog(messagebox.showerror, 'ファイルが見つかりません', str(required), parent=self.send_panel)
                    return

            env = os.environ.copy()
            for key in ('PYTHONPATH', 'PYTHONHOME'):
                env.pop(key, None)
            env['PYTHONNOUSERSITE'] = '1'
            env['PYTHONDONTWRITEBYTECODE'] = '1'

            check = subprocess.run(
                ['/usr/bin/python3', '-I', str(setup), '--check'],
                cwd=str(app_dir), env=env,
                stdin=subprocess.DEVNULL, timeout=10)
            if check.returncode != 0:
                subprocess.Popen(
                    ['/usr/bin/python3', '-I', str(setup)],
                    cwd=str(app_dir), env=env,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True)
                _L.dialog(messagebox.showinfo, '初期設定', 'アクセス設定の画面を開きました。\n設定完了後、もう一度ボタンを押してください。', parent=self.send_panel)
                return

            processes[name] = subprocess.Popen(
                ['/usr/bin/python3', str(target)],
                cwd=str(app_dir), env=env,
                stdin=subprocess.DEVNULL,
                start_new_session=True)

        except (OSError, subprocess.SubprocessError) as error:
            _L.dialog(messagebox.showerror, '起動できません', str(error), parent=self.send_panel)

    def open_receive_panel(self):
        """Launch the existing receive-control trial without altering efax or storage."""
        if self.receive_panel_proc is not None and self.receive_panel_proc.poll() is None:
            # Send OPEN to the existing receiver panel, which may be hidden.
            self._show_receiver()
            return
        # Installed receive components share the application directory.
        target = Path(__file__).resolve().parents[1] / 'receive' / 'receive_buttons.py'
        if not target.is_file():
            _L.dialog(messagebox.showerror, 'ファイルが見つかりません', str(target), parent=self.root)
            return
        try:
            self.receive_panel_started = time.time()
            self.receive_panel_proc = subprocess.Popen(
                ['/usr/bin/python3', str(target)], cwd=str(target.parent),
                start_new_session=True)
        except OSError as error:
            _L.dialog(messagebox.showerror, '起動できません', str(error))

    def open_receive_history(self):
        """Single desktop entry for sent history and the embedded receive inbox."""
        target = Path(__file__).resolve().parents[1] / 'history_gui.py'
        proc=getattr(self,'receive_history_proc',None)
        if proc is not None and proc.poll() is None:
            _L.dialog(messagebox.showinfo, '送受信履歴の確認', '既に起動しています。開いている画面を確認してください。', parent=self.root)
            return
        if not target.is_file():
            _L.dialog(messagebox.showerror, 'ファイルが見つかりません', str(target), parent=self.root)
            return
        try:
            self.receive_history_proc = subprocess.Popen(['/usr/bin/python3', str(target)], cwd=str(target.parent),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError as error:
            _L.dialog(messagebox.showerror, '受信履歴を開けません', str(error))

    def _show_receiver(self):
        try:
            with socket.socket(socket.AF_UNIX) as sock:
                sock.settimeout(1)
                runtime = Path(os.environ.get('XDG_RUNTIME_DIR') or tempfile.gettempdir())
                sock.connect(str(runtime / f'lazilyfax-receive-panel-{os.getuid()}.sock'))
                sock.sendall(b'OPEN')
        except OSError:
            _L.dialog(messagebox.showwarning, '受信操作', '受信操作パネルを再表示できません。')

    @staticmethod
    def root_path():
        # Existing history and FAX receiver remain in the installed application.
        return Path('/usr/lib/lazilyfax')

    def setup_tray(self):
        try:
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk, GLib, GdkPixbuf
            self.glib = GLib
            tray = Gtk.StatusIcon()
            tray.set_from_file(str(tray_icon_path('stopped')))
            tray.set_tooltip_text(_L.text(APP + ' — 停止中'))
            tray.connect('activate', lambda *_: self.show())
            tray.connect('popup-menu', self._tray_menu)
            tray.set_visible(True)
            self.tray = tray
            self.Gtk = Gtk
            # Gtk events share the Tk main thread by periodically servicing the GLib context.
            self.root.after(60, self.pump_gtk)
            return True
        except (ImportError, ValueError, RuntimeError) as exc:
            self.tray = None
            print('Tray unavailable:', exc)
            return False

    def pump_gtk(self):
        if self.closing:
            return
        context = self.glib.MainContext.default()
        for _ in range(20):
            if not context.pending():
                break
            context.iteration(False)
        self.root.after(60, self.pump_gtk)

    def _tray_menu(self, icon, button, time):
        menu = self.Gtk.Menu()
        for label, callback in (('開く', self.show), ('LazilyFAXを再起動', self.restart_system), ('終了', self.quit)):
            item = _L.widget(self.Gtk.MenuItem, label=label)
            item.connect('activate', lambda _item, cb=callback: self.root.after(0, cb))
            menu.append(item)
        menu.show_all()
        menu.popup(None, None, self.Gtk.StatusIcon.position_menu, icon, button, time)

    def show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def hide(self):
        if not self.tray:
            _L.dialog(messagebox.showinfo, 'トレイ未利用', 'トレイを使用できないため、画面は隠しません。終了は「終了」ボタンから行ってください。')
            return
        self.root.withdraw()

    def toggle_blink(self):
        self.demo_receiving = not getattr(self, 'demo_receiving', False)
        self.receiving = self.demo_receiving
        self.receive_state = 'receiving' if self.receiving else 'stopped'
        self.state_text.set('受信中（模擬表示）' if self.receiving else '停止中（模擬表示）')
        self._set_state_color('receiving' if self.receiving else 'stopped')
        self.wing.set_receiving(self.receiving)
        self.update_tray()

    def _set_state_color(self, state, mode=None):
        colors = {'stopped': '#94A3B8', 'receiving': '#F2C94C', 'unknown': '#CBD5E1'}
        color = ('#A6DDB0' if mode == 'once' else '#22A447') if state == 'waiting' else colors[state]
        self.state_indicator.itemconfigure(self.state_circle, fill=color)

    def update_tray(self):
        if self.tray:
            # Never infer receiver state from a translated label.
            state = 'receiving' if self.receiving else self.receive_state
            icon_path = tray_icon_path(state, self.blink_on)
            if icon_path != getattr(self, '_tray_frame', None):
                self.tray.set_from_file(str(icon_path))
                self._tray_frame = icon_path
            self.tray.set_tooltip_text(_L.text('LazilyFAX — 受信中' if self.receiving else 'LazilyFAX — ' + self.state_text.get()))

    def tick(self):
        if self.closing:
            return
        self.blink_on = not self.blink_on
        # The demo toggle remains for environments without a connected modem.
        # Observe the receiver worker, not the lifetime of its GUI window.
        # The worker may outlive or predate this main panel.
        mode = receiver_mode()
        detected = receive_status(process_running=mode is not None)
        voice = worker_status()
        if voice:
            detected = 'waiting' if voice['state'] in ('starting', 'waiting') else 'unknown' if voice['state'] in ('error', 'stopping') else 'receiving'
        self.receiving = detected == 'receiving' or getattr(self, 'demo_receiving', False)
        self.receive_state = 'receiving' if self.receiving else detected
        if not getattr(self, 'demo_receiving', False):
            waiting = '1回受信待機' if mode == 'once' else '常時受信待機'
            self.state_text.set((_L.text('留守番電話') + ' — ' + __import__('voicemail_ui').words().get(voice['state'], voice['state'])) if voice else {'receiving':'受信中', 'waiting':waiting, 'stopped':'停止中', 'unknown':'状態確認不可'}[detected])
            self._set_state_color(detected, mode)
        else:
            self._set_state_color('receiving')
        self.wing.set_receiving(self.receiving)
        if self.completions.poll():
            self.wing.completed()
        self.update_tray()
        self.root.after(550, self.tick)

    def show_receiver_before_restart(self):
        if worker_status():
            show_controls(self.root)
            return True
        if not receiver_running():
            return False
        _L.dialog(messagebox.showinfo, '受信処理が動作しています', '受信制御パネルを開きます。\n\n通信中の場合は完了を待ってから「停止」を押してください。\n停止後に、もう一度「LazilyFAXを再起動」を選んでください。', parent=self.root)
        self.open_receive_panel()
        return True

    def restart_system(self):
        if self.show_receiver_before_restart():
            return
        import importlib.util
        import signal

        if not _L.dialog(messagebox.askyesno, 'LazilyFAXを再起動', 'LazilyFAXの関連画面とポータルを閉じて再起動します。\n未保存の内容がある場合は先に保存してください。\n\n再起動しますか？', parent=self.root):
            return

        fd = None
        lifecycle = None
        try:
            source = Path(__file__).resolve().parents[1] / 'lifecycle.py'
            spec = importlib.util.spec_from_file_location(
                '_lazilyfax_restart_lifecycle', str(source))
            lifecycle = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(lifecycle)

            current = lifecycle.processes()
            for pid in current:
                if Path('/proc', str(pid)).stat().st_uid != os.getuid():
                    raise RuntimeError(
                        '別ユーザーのLazilyFAXが動作しています。再起動を中止しました。')

            # Check the shared activity lock before closing any windows.
            fd = lifecycle.acquire_activity()
            lifecycle.release_activity(fd)
            fd = None
            lifecycle.stop_idle(exclude_pid=os.getpid())

            # Keep modem activity blocked while closing the trial windows.
            fd = lifecycle.acquire_activity()
            if any(pid != os.getpid() for pid in lifecycle.processes()):
                raise RuntimeError(
                    'LazilyFAXの処理が残っています。再起動を中止しました。')

            base = self.root_path()
            idle_scripts = {
                str(base / 'receive'
                    / 'receive_buttons.py'),
                str(base / 'receive'
                    / 'receive_inbox.py'),
            }
            worker = str(
                base / 'receive'
                / 'receive_control.py')

            def trial_processes():
                found = {}
                for entry in Path('/proc').iterdir():
                    if not entry.name.isdigit():
                        continue
                    try:
                        args = (entry / 'cmdline').read_bytes().split(b'\0')
                        if (entry / 'stat').read_text().split(') ', 1)[1].startswith('Z'):
                            continue
                        exe = Path(os.readlink(entry / 'exe')).name
                        if exe in ('efax', 'efax-wire'):
                            raise RuntimeError(
                                'FAXエンジンが動作しています。再起動を中止しました。')
                        if not exe.startswith('python'):
                            continue
                        scripts = {os.fsdecode(arg) for arg in args[1:]}
                        if worker in scripts:
                            raise RuntimeError(
                                '受信処理が動作しています。停止後に再実行してください。')
                        matches = scripts & idle_scripts
                        if matches:
                            if entry.stat().st_uid != os.getuid():
                                raise RuntimeError(
                                    '別ユーザーの画面が動作しています。')
                            found[int(entry.name)] = (
                                matches, (entry / 'stat').read_text().rsplit(') ', 1)[1].split()[19])
                    except (OSError, ValueError, IndexError):
                        continue
                return found

            targets = trial_processes()
            for pid, identity in targets.items():
                if trial_processes().get(pid) == identity:
                    try:
                        os.kill(pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass

            deadline = time.monotonic() + 5
            while trial_processes():
                if time.monotonic() >= deadline:
                    raise RuntimeError(
                        '終了できない画面が残っています。再起動を中止しました。')
                time.sleep(0.1)

            if any(pid != os.getpid() for pid in lifecycle.processes()):
                raise RuntimeError(
                    'LazilyFAXの処理が再び起動しました。再起動を中止しました。')

            # exec closes the activity lock through its O_CLOEXEC flag.
            if self.tray:
                self.tray.set_visible(False)
            self.instance.release()
            try:
                os.execv('/usr/bin/python3', [
                    '/usr/bin/python3', str(Path(__file__).resolve())])
            except OSError:
                self.instance = SingleInstance(
                    lambda: self.root.after(0, self.show))
                if not self.instance.acquire():
                    self.root.destroy()
                    return
                if self.tray:
                    self.tray.set_visible(True)
                raise

        except BlockingIOError:
            if not self.show_receiver_before_restart():
                _L.dialog(messagebox.showinfo, '再起動できません', '送信またはモデム操作が動作しています。\n処理を停止または完了してから再実行してください。', parent=self.root)
        except Exception as error:
            _L.dialog(messagebox.showerror, '再起動を中止しました', str(error), parent=self.root)
        finally:
            if fd is not None:
                lifecycle.release_activity(fd)

    def quit(self):
        if worker_status():
            show_controls(self.root)
            return
        if receiver_running():
            _L.dialog(messagebox.showinfo, '受信処理が動作しています',
                      '受信待機・通信が動作しています。受信操作パネルで停止してから、もう一度終了してください。', parent=self.root)
            self.open_receive_panel()
            return
        if not _L.dialog(messagebox.askyesno, '終了確認',
                         'LazilyFAXの関連画面とトレイを終了します。未保存の内容は先に保存してください。\n\n本当に終了しますか？', parent=self.root):
            return
        try:
            import importlib.util
            source = Path(__file__).resolve().parent.parent / 'lifecycle.py'
            spec = importlib.util.spec_from_file_location('_lazilyfax_quit_lifecycle', source)
            lifecycle = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(lifecycle)
            for pid in lifecycle.processes():
                if Path('/proc', str(pid)).stat().st_uid != os.getuid():
                    raise RuntimeError('別ユーザーのLazilyFAXが動作しています。終了を中止しました。')
            lifecycle.stop_idle(exclude_pid=os.getpid())
        except Exception as error:
            _L.dialog(messagebox.showerror, '終了できません', str(error), parent=self.root)
            return
        self.closing = True
        if self.tray:
            self.tray.set_visible(False)
        self.instance.release()
        self.root.destroy()


def main():
    root = tk.Tk()
    _L.install(root)
    root.withdraw()
    app = App(root)
    if not app.instance.acquire():
        root.destroy()
        return
    if not app.setup_tray():
        app.show()
        _L.dialog(messagebox.showwarning, '通知領域を確認してください', 'Gtk 3トレイを利用できません。安全のため×ボタンでは画面を隠しません。\nLinux Mintでは python3-gi と gir1.2-gtk-3.0 が必要です。')
    root.after(550, app.tick)
    try:
        root.mainloop()
    finally:
        app.instance.release()


if __name__ == '__main__':
    main()
