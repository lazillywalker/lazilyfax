#!/usr/bin/env python3
"""Registration UI; only the main thread touches Tk widgets."""
import queue
import threading
import tkinter as tk
from tkinter import ttk
import gumroad_license as license
import license_i18n as i18n

class LicenseWindow:
    def __init__(self, root, diagnostic=False):
        self.words = i18n.CATALOG[i18n.selected_language()]
        self.root = root
        self.diagnostic = diagnostic
        self.events = queue.Queue()
        self.busy = False
        root.title('LazilyFAX — ' + self.words['menu'])
        root.geometry('720x430')
        root.minsize(720, 430)
        frame = ttk.Frame(root, padding=22); frame.pack(fill='both', expand=True)
        ttk.Label(frame, text=self.words['diagnostic_heading'] if diagnostic else self.words['heading'], font=('Sans', 16, 'bold')).pack(anchor='w')
        ttk.Label(frame, text=self.words['intro'], wraplength=670).pack(anchor='w', pady=8)
        self.email = tk.StringVar(); self.key = tk.StringVar()
        ttk.Label(frame, text=self.words['email']).pack(anchor='w')
        self.email_entry = ttk.Entry(frame, textvariable=self.email); self.email_entry.pack(fill='x')
        ttk.Label(frame, text=self.words['key']).pack(anchor='w', pady=(8, 0))
        self.key_entry = ttk.Entry(frame, textvariable=self.key, show='•'); self.key_entry.pack(fill='x')
        self.status = ttk.Label(frame, wraplength=670); self.status.pack(anchor='w', pady=10)
        self.button = ttk.Button(frame, text=self.words['check'] if diagnostic else self.words['save'], command=self.submit); self.button.pack(anchor='w')
        ttk.Label(frame, text=self.words['note'], wraplength=670).pack(anchor='w', pady=8)
        try:
            saved = license.load_credentials()
            self.email.set(saved['email']); self.key.set(saved['registration_number'])
            self.status.configure(text=self.words['saved'])
        except license.LicenseError as error:
            self.status.configure(text=self.words[error.state])
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.poll_id = root.after(100, self.poll)
    def submit(self):
        if self.busy: return
        email, key = self.email.get(), self.key.get()
        self.busy = True
        for widget in (self.button, self.email_entry, self.key_entry): widget.configure(state='disabled')
        self.status.configure(text=self.words['checking'])
        def worker():
            try:
                if self.diagnostic:
                    purchase = license.verify(email, key, allow_test=True)
                    kind = self.words['test_kind'] if purchase.get('test') is True else self.words['normal_kind']
                    self.events.put(self.words['checked'].format(kind=kind))
                else:
                    license.register(email, key)
                    self.events.put(self.words['active'])
            except license.LicenseError as error: self.events.put(self.words[error.state])
            except Exception: self.events.put(self.words['save_error'])
        threading.Thread(target=worker, daemon=True).start()
    def poll(self):
        try:
            result = self.events.get_nowait()
            self.busy = False
            for widget in (self.button, self.email_entry, self.key_entry): widget.configure(state='normal')
            self.status.configure(text=result)
        except queue.Empty: pass
        self.poll_id = self.root.after(100, self.poll)
    def close(self):
        if not self.busy:
            self.root.after_cancel(self.poll_id)
            self.root.destroy()

def main():
    root = tk.Tk(); LicenseWindow(root); root.mainloop()

if __name__ == '__main__': main()
