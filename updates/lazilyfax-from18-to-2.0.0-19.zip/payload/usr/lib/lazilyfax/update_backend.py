#!/usr/bin/env python3
"""Apply a pre-verified DEB sequence through APT after one polkit authentication."""

if __name__ == '__main__':
    import sys as _maintenance_sys
    from pathlib import Path as _MaintenancePath
    _maintenance_sys.path.insert(0, str(_MaintenancePath(__file__).resolve().parents[0]))
    from maintenance import guard_start as _maintenance_guard
    _maintenance_gate = _maintenance_guard()

from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import stat

sys.path.insert(0, str(Path(__file__).resolve().parent))
import update_core as core
import gumroad_license


def load_plan(path, expected_uid=None):
    path = Path(path)
    if path.is_symlink() or not path.is_absolute() or path.name != 'plan.json':
        raise core.UpdateError('Invalid installation plan')
    work = path.parent
    if not work.name.startswith('lazilyfax-update-') or work.is_symlink():
        raise core.UpdateError('Invalid update workspace')
    if expected_uid is not None and (path.stat().st_uid != expected_uid or work.stat().st_uid != expected_uid):
        raise core.UpdateError('Update workspace owner mismatch')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > 256 * 1024:
            raise core.UpdateError('Invalid installation plan file')
        if expected_uid is not None and info.st_uid != expected_uid:
            raise core.UpdateError('Update plan owner mismatch')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(256 * 1024 + 1)
        if len(data) > 256 * 1024: raise core.UpdateError('Plan too large')
        plan = json.loads(data)
    finally:
        os.close(fd)
    if plan.get('format') != 'lazilyfax-install-plan-v1': raise core.UpdateError('Invalid plan format')
    steps = plan.get('steps')
    if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
        raise core.UpdateError('Invalid installation steps')
    version = core.valid_version(plan.get('base_version'))
    for step in steps:
        if not isinstance(step, dict) or step.get('from_version') != version:
            raise core.UpdateError('Discontinuous installation plan')
        target = core.valid_version(step.get('to_version'))
        if not core.newer(target, version): raise core.UpdateError('Installation would not move forward')
        # The privileged caller treats the plan only as a requested version
        # sequence. User-owned DEBs and their hashes are never trusted/read.
        if expected_uid is not None:
            version = target
            continue
        deb = Path(step['deb'])
        if not deb.is_absolute() or deb.is_symlink() or deb.suffix != '.deb':
            raise core.UpdateError('Invalid DEB path')
        rel = deb.relative_to(work)
        p = work
        for part in rel.parts:
            p = p / part
            if p.is_symlink(): raise core.UpdateError('Symlink in update path')
        if core.digest(deb.read_bytes()) != step.get('sha256'):
            raise core.UpdateError('Prepared DEB checksum mismatch')
        for field, expected in [('Package','lazilyfax'),('Version',target),('Architecture','amd64')]:
            actual = subprocess.check_output(['dpkg-deb','-f',str(deb),field],text=True).strip()
            if actual != expected: raise core.UpdateError('Prepared DEB identity mismatch')
        version = target
    if version != plan.get('target_version'): raise core.UpdateError('Plan does not reach target')
    return plan


def prepare_trusted_plan(request, workspace, installed_root=Path('/'), fetcher=core.fetch):
    current = request['base_version']
    official = core.check_metadata(current, fetcher)
    if official is None or official['package_version'] != request['target_version']:
        raise core.UpdateError('Official update changed. Check for updates again.')
    edges = official.get('steps') or [dict(official, base_version=current)]
    approved = [(e['base_version'], e['package_version']) for e in edges]
    requested = [(e['from_version'], e['to_version']) for e in request['steps']]
    if approved != requested:
        raise core.UpdateError('Update sequence does not match the official catalog')
    path = core.prepare(official, current, workspace, installed_root, fetcher)
    return load_plan(path)


def install_plan(plan, current_version=core.installed_version, runner=subprocess.run, progress=None):
    """A failed stage never starts later stages; a retry uses installed package state."""
    if current_version() != plan['base_version']:
        raise core.UpdateError('Installed version changed. Check for updates again.')
    env = os.environ.copy()
    env['DEBIAN_FRONTEND'] = 'noninteractive'
    for index, step in enumerate(plan['steps'], 1):
        if current_version() != step['from_version']:
            raise core.UpdateError('Installed version does not match next stage')
        if core.digest(Path(step['deb']).read_bytes()) != step['sha256']:
            raise core.UpdateError('Prepared DEB changed before installation')
        if progress: progress(index, len(plan['steps']), step['to_version'])
        result = runner(['/usr/bin/apt-get','install','-y',step['deb']],
                        env=env,stdin=subprocess.DEVNULL,check=False)
        if result.returncode != 0: return result.returncode
        if current_version() != step['to_version']:
            raise core.UpdateError('Installed version does not match completed stage')
    return 0


def main():
    if os.geteuid() != 0: raise core.UpdateError('Administrator authentication is required')
    uid = int(os.environ['PKEXEC_UID'])
    gumroad_license.require_active(uid=uid)
    path = Path(sys.argv[1])
    if path.parent.parent != Path(tempfile.gettempdir()):
        raise core.UpdateError('Unexpected update workspace location')
    request = load_plan(path,uid)
    if core.installed_version() != request['base_version']:
        raise core.UpdateError('Installed version changed. Check for updates again.')
    print('Verifying official update in a private administrator workspace…', flush=True)
    # mkdtemp creates a root-owned 0700 directory; no user-supplied paths or
    # packages cross this trust boundary. Cleanup also runs after failure.
    with tempfile.TemporaryDirectory(prefix='lazilyfax-update-root-', dir='/var/tmp') as folder:
        work = Path(folder)
        info = work.stat()
        if info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o700:
            raise core.UpdateError('Unsafe administrator workspace')
        plan = prepare_trusted_plan(request, work)
        gumroad_license.require_active(uid=uid)
        return install_plan(plan,progress=lambda i,n,v:print(f'LAZILYFAX_STEP {i}/{n} {v}',flush=True))

if __name__ == '__main__':
    try: raise SystemExit(main())
    except Exception as error:
        print('LazilyFAX update: '+str(error),file=sys.stderr)
        raise SystemExit(1)
