"""Gumroad purchase verification. Local state is credentials, never authority."""
import license_i18n
import json
import os
from pathlib import Path
import pwd
import stat
import tempfile
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPRedirectHandler

CONFIG = Path(__file__).with_name('gumroad_product.json')
LIMIT = 128 * 1024
MESSAGES = {
    'test_purchase': 'テスト購入の登録番号です。本番の更新には利用できません。',
    'active': '有効な登録です。更新を利用できます。',
    'unregistered': '未登録です。設定の「ライセンス登録」から登録してください。',
    'invalid': '登録番号が無効、または取り消されています。',
    'refunded': '返金済みの購入です。更新できません。',
    'revoked': '取消・支払異議のある購入です。更新できません。',
    'mismatch': '購入メールアドレスまたは商品が一致しません。',
    'unavailable': '購入状態を確認できません。通信環境を確認して再試行してください。登録は保持されます。',
    'not_configured': 'Gumroad商品IDが未設定です。販売者による設定が必要です。',
    'corrupt': '登録情報を読み込めません。ライセンス登録画面で再登録してください。',
}

class LicenseError(Exception):
    def __init__(self, state):
        self.state = state
        super().__init__(license_i18n.text(state))

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise LicenseError('unavailable')

def credentials_path(uid=None):
    uid = os.getuid() if uid is None else uid
    return Path(pwd.getpwuid(uid).pw_dir) / '.config/lazilyfax/gumroad-license.json'

def product_id():
    try:
        value = json.loads(CONFIG.read_text())['product_id']
        if not isinstance(value, str) or not value.strip() or len(value) > 200:
            raise ValueError()
        return value.strip()
    except (OSError, ValueError, KeyError, TypeError):
        raise LicenseError('not_configured') from None

def normalize(email, key):
    if not isinstance(email, str) or not isinstance(key, str):
        raise LicenseError('corrupt')
    if any(ord(c) < 32 or ord(c) == 127 for c in email + key):
        raise LicenseError('unregistered')
    email, key = email.strip().casefold(), key.strip().upper()
    if email.count('@') != 1 or not all(email.split('@')) or any(c.isspace() for c in email + key) or len(email) > 254 or not key or len(key) > 200:
        raise LicenseError('unregistered')
    return email, key

def load_credentials(path=None, uid=None):
    path = credentials_path(uid) if path is None else Path(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as stream:
            meta = os.fstat(stream.fileno())
            owner = os.getuid() if uid is None else uid
            if not stat.S_ISREG(meta.st_mode) or meta.st_uid != owner or meta.st_size > 4096:
                raise ValueError()
            data = json.loads(stream.read(4097))
        email, key = normalize(data['email'], data['registration_number'])
        return {'email': email, 'registration_number': key}
    except FileNotFoundError:
        raise LicenseError('unregistered') from None
    except (OSError, ValueError, KeyError, TypeError):
        raise LicenseError('corrupt') from None

def save_credentials(email, key, path=None):
    email, key = normalize(email, key)
    path = credentials_path() if path is None else Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix='.license-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump({'schema': 1, 'email': email, 'registration_number': key}, stream)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def request_verification(product, key):
    request = Request('https://api.gumroad.com/v2/licenses/verify', data=urlencode({
        'product_id': product, 'license_key': key, 'increment_uses_count': 'false',
    }).encode(), headers={'User-Agent': 'LazilyFAX-Gumroad/1'})
    try:
        not_found = False
        try:
            response = build_opener(NoRedirect()).open(request, timeout=20)
        except HTTPError as error:
            if error.code != 404:
                error.close()
                raise LicenseError('unavailable') from None
            not_found = True
            response = error
        with response:
            raw = response.read(LIMIT + 1)
        if len(raw) > LIMIT: raise ValueError()
        value = json.loads(raw)
        if not isinstance(value, dict): raise ValueError()
        if not_found and value.get('success') is not False: raise ValueError()
        return value
    except (OSError, URLError, ValueError):
        raise LicenseError('unavailable') from None

def verify(email, key, product=None, transport=request_verification, *, allow_test=False):
    email, key = normalize(email, key)
    product = product_id() if product is None else product
    data = transport(product, key)
    if not isinstance(data, dict): raise LicenseError('unavailable')
    if data.get('success') is False: raise LicenseError('invalid')
    p = data.get('purchase')
    if data.get('success') is not True or not isinstance(p, dict):
        raise LicenseError('unavailable')
    if p.get('product_id') != product or not isinstance(p.get('email'), str) or p['email'].strip().casefold() != email:
        raise LicenseError('mismatch')
    if p.get('license_key', key) != key: raise LicenseError('mismatch')
    # Missing or non-boolean risk flags must never silently grant updates.
    if any(type(p.get(field)) is not bool for field in ('refunded', 'chargebacked', 'disputed', 'dispute_won')):
        raise LicenseError('unavailable')
    if p['refunded']: raise LicenseError('refunded')
    if p['chargebacked'] or (p['disputed'] and not p['dispute_won']) or p.get('license_disabled') is True:
        raise LicenseError('revoked')
    # This edition is a one-time purchase, not a subscription entitlement.
    if p.get('subscription_id') or p.get('recurrence'):
        raise LicenseError('revoked')
    if not isinstance(p.get('sale_id'), str) or not p['sale_id']:
        raise LicenseError('unavailable')
    if 'test' in p and type(p['test']) is not bool:
        raise LicenseError('unavailable')
    if p.get('test') is True and not allow_test:
        raise LicenseError('test_purchase')
    return p

def require_active(uid=None):
    saved = load_credentials(uid=uid)
    return verify(saved['email'], saved['registration_number'])

def register(email, key, path=None, verifier=verify):
    result = verifier(email, key)
    save_credentials(email, key, path)
    return result
