"""User-owned license backup, separate from privileged FAX data archives."""
import json
import os
from pathlib import Path
import stat
import tempfile
import gumroad_license as license
FORMAT = 'lazilyfax-license-backup-v1'
EXTENSION = '.lfaxlicense'

def export_file(target, source=None):
    saved = license.load_credentials(source)
    payload = {'format': FORMAT, 'product_id': license.product_id(), **saved}
    target = Path(target)
    fd, temporary = tempfile.mkstemp(prefix='.license-backup-', dir=target.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(payload,stream);stream.write('\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,target)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)

def read_file(source):
    try:
        fd=os.open(source,os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd,'rb') as stream:
            info=os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size>4096:raise ValueError()
            data=json.loads(stream.read(4097))
        if not isinstance(data,dict) or data.get('format')!=FORMAT:raise ValueError()
        if data.get('product_id')!=license.product_id():raise license.LicenseError('mismatch')
        email,key=license.normalize(data['email'],data['registration_number'])
        return {'email':email,'registration_number':key}
    except (OSError,ValueError,KeyError,TypeError):
        raise license.LicenseError('corrupt') from None

def restore_file(source, destination=None):
    saved=read_file(source)
    # No authority is imported. Every update still verifies online.
    license.save_credentials(saved['email'],saved['registration_number'],destination)

def dialog(root, restore=False):
    from tkinter import filedialog,messagebox
    import license_i18n as i
    title=i.text('license_restore' if restore else 'license_export')
    try:
        if restore:
            path=filedialog.askopenfilename(parent=root,title=title,filetypes=[('LazilyFAX license','*'+EXTENSION)])
            if not path:return
            saved=read_file(path)
            if not messagebox.askyesno(title,i.text('license_restore_confirm'),parent=root):return
            # Apply the exact data validated before confirmation, not a changed source.
            license.save_credentials(saved['email'],saved['registration_number'])
            messagebox.showinfo(title,i.text('license_restored'),parent=root)
        else:
            if not messagebox.askyesno(title,i.text('license_export_confirm'),parent=root):return
            path=filedialog.asksaveasfilename(parent=root,title=title,initialfile='LazilyFAX-registration'+EXTENSION,defaultextension=EXTENSION,filetypes=[('LazilyFAX license','*'+EXTENSION)])
            if not path:return
            export_file(path)
            messagebox.showinfo(title,i.text('license_exported'),parent=root)
    except license.LicenseError as error:messagebox.showerror(title,str(error),parent=root)
    except OSError:messagebox.showerror(title,i.text('save_error'),parent=root)
