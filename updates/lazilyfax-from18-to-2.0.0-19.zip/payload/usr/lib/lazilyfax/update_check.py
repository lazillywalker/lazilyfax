#!/usr/bin/env python3
"""Native update window. Network/build work runs away from the Tk thread."""

# Keep UI translations local; the installed engine and data remain unchanged.
import sys as _de_sys
from pathlib import Path as _DePath
_de_sys.path[:0] = [str(_DePath(__file__).resolve().parent), '/usr/lib/lazilyfax', '/usr/lib/lazilyfax/receive/app']
import language as _de_language
import translation_catalog as _de_catalog



if __name__ == '__main__':
    import sys as _maintenance_sys
    from pathlib import Path as _MaintenancePath
    _maintenance_sys.path.insert(0, str(_MaintenancePath(__file__).resolve().parents[0]))
    from maintenance import guard_start as _maintenance_guard
    _maintenance_gate = _maintenance_guard()

# Shared translations, including isolated and legacy entry points.
import sys as _catalog_sys
from pathlib import Path as _CatalogPath
_catalog_sys.path.insert(0, str(_CatalogPath(__file__).resolve().parents[0]))
from translation_catalog import translations as _translations


import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import lifecycle
import language
import update_core as core
import gumroad_license

COPY = _translations('update_check_copy')

class UpdateWindow:
 def __init__(self,root):
  self.root=root
  self.words=COPY.get(language.get_language(),COPY['en'])
  self.current=core.installed_version()
  self.info=None;self.work=None;self.busy=False;self.events=queue.Queue()
  root.title('LazilyFAX — '+self.words['title']);root.geometry('650x310');root.minsize(600,300)
  frame=ttk.Frame(root,padding=22);frame.pack(expand=True,fill='both')
  ttk.Label(frame,text=self.words['title'],font=('Sans',17,'bold')).pack(anchor='w')
  ttk.Label(frame,text=self.words['current'].format(version=self.current)).pack(anchor='w',pady=(10,5))
  self.status=ttk.Label(frame,wraplength=590);self.status.pack(anchor='w',pady=8)
  ttk.Label(frame,text=self.words['note'],wraplength=590).pack(anchor='w',pady=8)
  row=ttk.Frame(frame);row.pack(side='bottom',fill='x')
  self.check_button=ttk.Button(row,text=self.words['check'],command=self.check);self.check_button.pack(side='left')
  self.apply_button=ttk.Button(row,text=self.words['apply'],command=self.apply,state='disabled');self.apply_button.pack(side='left',padx=8)
  self.close_button=ttk.Button(row,text=self.words['close'],command=self.close);self.close_button.pack(side='right')
  root.protocol('WM_DELETE_WINDOW',self.close)
  root.after(100,self.poll);self.check()
 def run(self,kind,operation):
  self.busy=True;self.check_button.configure(state='disabled');self.apply_button.configure(state='disabled')
  def worker():
   try:self.events.put((kind,operation(),None))
   except Exception as error:self.events.put((kind,None,str(error)))
  threading.Thread(target=worker,daemon=True).start()
 def check(self):
  if self.busy:return
  self.info=None;self.status.configure(text=self.words['checking'])
  self.run('check',lambda:(gumroad_license.require_active(),core.check_metadata(self.current))[1])
 def apply(self):
  if self.busy or not self.info:return
  if not messagebox.askyesno(self.words['title'],self.words['confirm'],parent=self.root):return
  # A read-only guard first; GUI windows may remain until the download is ready.
  try:
   fd=lifecycle.acquire_activity()
   try:
    active=lifecycle.processes()
    if any(n=='efax' or n in lifecycle.BUSY for n in active.values()):
     raise core.UpdateError('Stop FAX/modem activity before updating.')
   finally:lifecycle.release_activity(fd)
  except Exception as error:
   messagebox.showerror(self.words['error'],str(error),parent=self.root);return
  self.work=Path(tempfile.mkdtemp(prefix='lazilyfax-update-',dir='/tmp'))
  self.status.configure(text=self.words['preparing'])
  self.run('prepare',lambda:(gumroad_license.require_active(),core.prepare(self.info,self.current,self.work,
       progress=lambda i,n,v:self.events.put(('progress',(i,n,v),None))))[1])
 def poll(self):
  try:kind,result,error=self.events.get_nowait()
  except queue.Empty:self.root.after(100,self.poll);return
  if kind=='progress':
   i,n,v=result;self.status.configure(text=self.words['step'].format(index=i,count=n,version=v))
   self.root.after(100,self.poll);return
  self.busy=False;self.check_button.configure(state='normal')
  if error:
   self.status.configure(text=self.words['error']+'\n'+error)
  elif kind=='check':
   self.info=result
   self.status.configure(text=self.words['available'].format(version=result['package_version'],count=len(result.get('steps',[])) or 1) if result else self.words['latest'])
   if result:self.apply_button.configure(state='normal')
  else:
   try:
    # Refuse other users and new activity before closing any related idle windows.
    if core.installed_version()!=self.current:raise core.UpdateError('Installed version changed. Check again.')
    for pid in lifecycle.processes():
     if Path('/proc',str(pid)).stat().st_uid!=os.getuid():raise core.UpdateError('Another user is running LazilyFAX.')
    lifecycle.stop_idle(exclude_pid=os.getpid())
    subprocess.Popen(['/usr/bin/python3',str(Path(__file__).with_name('update_install.py')),
                      str(result),str(os.getpid()),language.get_language()],start_new_session=True)
    self.root.destroy();return
   except Exception as error:
    self.status.configure(text=self.words['error']+'\n'+str(error))
  self.root.after(100,self.poll)
 def close(self):
  if self.busy:return
  self.root.destroy()

def main():
 root=tk.Tk()
 try:UpdateWindow(root)
 except Exception as error:
  root.withdraw();messagebox.showerror('LazilyFAX Update',str(error),parent=root);root.destroy();return 1
 root.mainloop();return 0
if __name__=='__main__':raise SystemExit(main())
