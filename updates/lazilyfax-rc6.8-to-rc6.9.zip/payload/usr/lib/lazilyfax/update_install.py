#!/usr/bin/env python3
"""Show sequential installation progress and a clear completion state."""
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText
import update_core as core
from update_backend import load_plan

TEXT = {
 'ja': ('更新の適用','管理者認証後、更新を順番に適用します。',
        '更新が完了しました。\n「LazilyFAXを起動」を押してください。',
        '更新は完了していません。下の記録を確認してください。',
        'LazilyFAXを起動','閉じる','更新中 {step}：{version}','起動できません'),
 'en': ('Install Updates','Updates will be installed in order after administrator authentication.',
        'Update completed.\nPress “Start LazilyFAX”.',
        'Update did not complete. Check the log below.',
        'Start LazilyFAX','Close','Installing {step}: {version}','Could Not Start'),
 'ko': ('업데이트 적용','관리자 인증 후 업데이트를 순서대로 적용합니다.',
        '업데이트가 완료되었습니다.\n“LazilyFAX 시작”을 눌러 주세요.',
        '업데이트가 완료되지 않았습니다. 아래 로그를 확인해 주세요.',
        'LazilyFAX 시작','닫기','업데이트 중 {step}: {version}','시작할 수 없습니다'),
}


SUMMARY = {
    'ja': ('更新が完了しました。', '更新後の版：{version}', '「LazilyFAXを起動」を押してください。', '更新は完了していません。上のエラー内容を確認してください。'),
    'en': ('Update completed.', 'Installed version: {version}', 'Press “Start LazilyFAX”.', 'Update did not complete. Check the errors above.'),
    'ko': ('업데이트가 완료되었습니다.', '설치된 버전: {version}', '“LazilyFAX 시작”을 눌러 주세요.', '업데이트가 완료되지 않았습니다. 위의 오류를 확인해 주세요.'),
}


def finish_install(events, folder, code, result, target):
    words = SUMMARY.get(code, SUMMARY['en'])
    lines = [words[0], words[1].format(version=target), words[2]] if result == 0 else [words[3]]
    footer = '\n' + '\n'.join(lines) + '\n'
    try:
        with (Path(folder) / 'install.log').open('a', encoding='utf-8') as stream:
            stream.write(footer)
    except OSError as error:
        events.put(('line', str(error) + '\n'))
    events.put(('line', footer))
    events.put(('done', result))


def wait_for_exit(pid):
    for _ in range(100):
        try:
            if Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].startswith('Z'): return
        except FileNotFoundError: return
        time.sleep(.1)
    raise RuntimeError('Update window is still running')


def start_application(root, words):
    try:
        subprocess.Popen(['/usr/bin/lazilyfax'], start_new_session=True)
    except OSError as error:
        messagebox.showerror(words[7],str(error),parent=root)
        return
    root.destroy()


def main():
    path=Path(sys.argv[1]).absolute();pid=int(sys.argv[2]);words=TEXT.get(sys.argv[3],TEXT['en'])
    plan=load_plan(path)
    root=tk.Tk();root.title('LazilyFAX — '+words[0]);root.geometry('800x530')
    status=ttk.Label(root,text=words[1],padding=16,wraplength=750,font=('Sans',14,'bold'))
    status.pack(fill='x')
    log=ScrolledText(root,wrap='word',height=18);log.pack(fill='both',expand=True,padx=12)
    row=ttk.Frame(root,padding=12);row.pack(fill='x')
    start=ttk.Button(row,text=words[4],command=lambda:start_application(root,words),state='disabled')
    start.pack(side='left')
    close=ttk.Button(row,text=words[5],command=root.destroy,state='disabled');close.pack(side='right')
    root.protocol('WM_DELETE_WINDOW',lambda:None)
    events=queue.Queue()
    def worker():
        result = 1
        try:
            wait_for_exit(pid)
            backend=Path(__file__).with_name('update_backend.py')
            proc=subprocess.Popen(['/usr/bin/pkexec','/usr/bin/python3','-I',str(backend),str(path)],
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
            with (path.parent/'install.log').open('w',encoding='utf-8') as out:
                for line in proc.stdout:
                    out.write(line);out.flush();events.put(('line',line))
            result=proc.wait()
            if result==0 and core.installed_version()!=plan['target_version']:
                raise RuntimeError('Installed version does not match update plan')
        except Exception as error:
            result = 1
            events.put(('line',str(error)+'\n'))
        finally:
            finish_install(events, path.parent, sys.argv[3], result, plan['target_version'])
    def poll():
        while True:
            try: kind,value=events.get_nowait()
            except queue.Empty:
                root.after(100,poll);return
            if kind=='line':
                if value.startswith('LAZILYFAX_STEP '):
                    _,step,version=value.strip().split()
                    status.configure(text=words[6].format(step=step,version=version))
                log.insert('end',value);log.see('end')
            else:
                log.configure(state='disabled')
                text=(words[2]+'\n'+plan['target_version']) if value==0 else words[3]
                status.configure(text=text,foreground='#166534' if value==0 else '#991B1B')
                if value==0:
                    start.configure(state='normal')
                    root.after_idle(lambda:messagebox.showinfo(words[0],text,parent=root))
                close.configure(state='normal');root.protocol('WM_DELETE_WINDOW',root.destroy)
                return
    threading.Thread(target=worker,daemon=True).start();root.after(100,poll);root.mainloop()

if __name__=='__main__': main()
