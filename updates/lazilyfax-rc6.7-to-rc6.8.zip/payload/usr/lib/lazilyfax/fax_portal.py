#!/usr/bin/env python3

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import html
from lifecycle import stop_idle
import os
import subprocess
import sys
import threading

from language import t, LANG
import language_settings
import header_settings
from paths import APP_DIR, FAX_GUI, FAX_VIEWER, HEADER_FILE, LANGUAGE_CONF

LANGUAGE_FILE = LANGUAGE_CONF
MODEM_CHECK = APP_DIR / "modem_check.py"
SETUP_CHECK = APP_DIR / "setup_check.py"
UPDATE_CHECK = APP_DIR / "update_check.py"
UPDATE_APPLY = APP_DIR / "update_apply.py"

MANUAL_DIR = Path("/usr/share/doc/lazilyfax")

PHONEBOOK_URL = "http://localhost/cgi-bin/faxbook.cgi"
FAXLOG_URL = "http://localhost/cgi-bin/faxlog.cgi"

HOST = "127.0.0.1"
PORT = 8765



# =========================================================
# GUI二重起動防止
# =========================================================

_gui_lock = threading.Lock()
_gui_processes = {}


def launch_gui(name, script):
    with _gui_lock:
        proc = _gui_processes.get(name)

        if proc is not None and proc.poll() is None:
            return False

        proc = subprocess.Popen(
            [sys.executable, str(script)],
            cwd=APP_DIR,
            start_new_session=True
        )

        _gui_processes[name] = proc
        return True


# =========================================================
# HTML
# =========================================================

PDF_COPY = {
 'ja': ('PDF作成', 'PDFや画像を並べて、1つのPDFに保存します。'),
 'en': ('Create PDF', 'Arrange PDFs and images and save them as one PDF.'),
 'ko': ('PDF 만들기', 'PDF와 이미지를 정렬하고 하나의 PDF로 저장합니다.'),
}


def make_html():
    LANG, t = language_settings.get_translation()
    pdf_title, pdf_description = PDF_COPY.get(LANG, PDF_COPY["en"])
    return f"""<!DOCTYPE html>
<html lang="{LANG}">
<head>
<meta charset="UTF-8">

<title>{t("portal_title")}</title>

<style>

body {{
    font-family: sans-serif;
    background: #f4f4f4;
    margin: 0;
    padding: 0;
}}

.container {{
    width: 90%;
    max-width: 650px;
    margin: 50px auto;
}}

h1 {{
    text-align: center;
    margin-bottom: 35px;
}}

.card {{
    display: block;
    background: white;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 22px;
    margin-bottom: 18px;

    text-decoration: none;
    color: #222;

    font-size: 20px;
    font-weight: bold;

    transition: 0.15s;
}}

.card:hover {{
    background: #eeeeee;
}}

.description {{
    display: block;
    margin-top: 8px;
    font-size: 14px;
    font-weight: normal;
    color: #666;
}}

.shutdown {{
    margin-top: 35px;
    text-align: center;
}}

.shutdown a {{
    color: #b00020;
    text-decoration: none;
    font-weight: bold;
    border: 1px solid #b00020;
    padding: 8px 14px;
    border-radius: 6px;
    display: inline-block;
}}


/* LazilyFAX unified blue theme - presentation only */
body {{ background: #F3F6FA; color: #334155; }}
h1 {{ color: #1F2937; }}
.card {{ border: 1px solid #DCE5F0; box-shadow: 0 2px 8px rgba(28,55,85,.06); color: #2563A6; }}
.card:hover {{ background: #EAF3FD; border-color: #9EC3E7; }}
.description {{ color: #64748B; }}
.shutdown a {{ color: #B42332; border-color: #B42332; }}
.update-button {{ background: #2563A6; color: #FFFFFF; border-color: #2563A6; }}
.update-button:hover {{ background: #1D4F85; }}
.status {{ background: #EAF3FD; }}

</style>

</head>

<body>

<div class="container">

<h1>{t("portal_title")}</h1>


<a class="card" href="/send">
    {t("portal_send")}

    <span class="description">
        {t("portal_send_description")}
    </span>
</a>


<a
    class="card"
    href="{PHONEBOOK_URL}"
    target="_blank"
    rel="noopener noreferrer"
>
    {t("portal_phonebook")}

    <span class="description">
        {t("portal_phonebook_description")}
    </span>
</a>



<a
    class="card"
    href="{FAXLOG_URL}"
    target="_blank"
    rel="noopener noreferrer"
>
    {t("portal_faxlog")}

    <span class="description">
        {t("portal_faxlog_description")}
    </span>
</a>


<a class="card" href="/viewer">
    {t("portal_viewer")}

    <span class="description">
        {t("portal_viewer_description")}
    </span>
</a>


<a class="card" href="/pdf-create">
    {pdf_title}
    <span class="description">{pdf_description}</span>
</a>


<a class="card" href="/header-settings">
    {t("portal_header_settings")}

    <span class="description">
        {t("portal_header_settings_description")}
    </span>
</a>


<a class="card" href="/modem-settings">
    {t("portal_modem_settings")}

    <span class="description">
        {t("portal_modem_settings_description")}
    </span>
</a>


<a class="card" href="/setup-check">
    {t("portal_setup_check")}

    <span class="description">
        {t("portal_setup_check_description")}
    </span>
</a>


<a class="card" href="/language-settings">
    {t("portal_language_settings")}

    <span class="description">
        {t("portal_language_settings_description")}
    </span>
</a>



<a class="card" href="/update-check">
    {t("portal_update_check")}

    <span class="description">
        {t("portal_update_check_description")}
    </span>
</a>


<a class="card" href="/manual" target="_blank">
    { {"ja": "ユーザーマニュアル", "en": "User Manual", "ko": "사용자 설명서"}.get(LANG, "User Manual") }
    <span class="description">
        { {"ja": "PDF形式のユーザーマニュアル", "en": "PDF User Manual", "ko": "PDF 사용자 설명서"}.get(LANG, "PDF User Manual") }
    </span>
</a>


<div class="shutdown">
    <a href="/shutdown">
        {t("portal_exit")}
    </a>
</div>


</div>

</body>
</html>
"""




def make_update_check_html():
    subprocess.Popen([sys.executable, str(UPDATE_CHECK)], cwd=APP_DIR,
                     start_new_session=True)
    code, _ = language_settings.get_translation()
    message = {"ja": "アップデート確認画面を開きました。このタブは閉じてください。",
               "en": "The update window is open. You can close this tab.",
               "ko": "업데이트 확인 창을 열었습니다. 이 탭을 닫아 주세요."}.get(code)
    return '<!doctype html><meta charset="utf-8"><p>' + html.escape(message) + '</p>'


# =========================================================
# HTTP
# =========================================================

class PortalHandler(BaseHTTPRequestHandler):

    def send_html(self, html, status=200):
        data = html.encode("utf-8")

        self.send_response(status)
        self.send_header(
            "Content-Type",
            "text/html; charset=utf-8"
        )
        self.send_header(
            "Content-Length",
            str(len(data))
        )
        self.end_headers()

        self.wfile.write(data)


    def redirect_home(self):
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()


    def open_text_file(self, file_path):

        if not file_path.exists():
            self.send_html(
                f"<h2>{t('portal_launch_error')}</h2>"
                f"<pre>{file_path}</pre>"
            )
            return False

        try:
            subprocess.Popen(
                ["xdg-open", str(file_path)],
                cwd=APP_DIR,
                start_new_session=True
            )

        except Exception as e:
            self.send_html(
                f"<h2>{t('portal_launch_error')}</h2>"
                f"<pre>{e}</pre>"
            )
            return False

        return True


    def send_manual(self):
        LANG, _ = language_settings.get_translation()
        lang = str(LANG).lower().split("_")[0].split("-")[0]
        filename = f"manual_{lang}.pdf" if lang in ("ja", "en", "ko") else "manual_en.pdf"
        pdf = MANUAL_DIR / filename

        if not pdf.is_file():
            self.send_error(404, "Manual not found")
            return

        data = pdf.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition", "inline; filename=" + filename)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path == "/header-settings":
            header_settings.handle_post(self)
            return
        if self.path == "/language-settings":
            language_settings.handle_post(self)
            return
        self.send_error(404)

    def do_GET(self):
        LANG, t = language_settings.get_translation()

        if self.path == "/manual":
            self.send_manual()
            return


        # -----------------------------------------------
        # メイン画面
        # -----------------------------------------------

        if self.path == "/":
            self.send_html(make_html())
            return


        # -----------------------------------------------
        # FAX送信
        # -----------------------------------------------

        if self.path == "/send":

            try:
                launch_gui(
                    "send",
                    FAX_GUI
                )

            except Exception as e:
                self.send_html(
                    f"<h2>{t('portal_launch_error')}</h2>"
                    f"<pre>{e}</pre>"
                )
                return

            self.redirect_home()
            return


        # -----------------------------------------------
        # FAXプレビュー
        # -----------------------------------------------

        if self.path == "/pdf-create":
            try:
                launch_gui("pdf-create", APP_DIR / "pdf_bundle.py")
            except OSError as error:
                self.send_html(f"<h2>{t('portal_launch_error')}</h2><pre>{html.escape(str(error))}</pre>")
                return
            self.redirect_home()
            return

        if self.path == "/viewer":

            try:
                launch_gui(
                    "viewer",
                    FAX_VIEWER
                )

            except Exception as e:
                self.send_html(
                    f"<h2>{t('portal_launch_error')}</h2>"
                    f"<pre>{e}</pre>"
                )
                return

            self.redirect_home()
            return


        # -----------------------------------------------
        # ヘッダー設定
        # -----------------------------------------------

        if self.path in ("/header-settings", "/header-settings?saved=1"):
            header_settings.handle_get(self)
            return


        # -----------------------------------------------
        # FAXモデム設定
        # -----------------------------------------------

        if self.path == "/modem-settings":

            try:
                launch_gui(
                    "modem",
                    MODEM_CHECK
                )

            except Exception as e:
                self.send_html(
                    f"<h2>{t('portal_launch_error')}</h2>"
                    f"<pre>{e}</pre>"
                )
                return

            self.redirect_home()
            return


        # -----------------------------------------------
        # セットアップ確認
        # -----------------------------------------------

        if self.path == "/setup-check":

            try:
                launch_gui(
                    "setup",
                    SETUP_CHECK
                )

            except Exception as e:
                self.send_html(
                    f"<h2>{t('portal_launch_error')}</h2>"
                    f"<pre>{e}</pre>"
                )
                return

            self.redirect_home()
            return


        # -----------------------------------------------
        # 言語設定
        # -----------------------------------------------

        if self.path == "/language-settings?saved=1":
            self.send_html(language_settings.page(
                message=language_settings.COPY[LANG]["saved"],
                success=True
            ))
            return

        if self.path == "/language-settings":
            # Desktop-only portal: reuse the existing child GUI lifecycle.
            # A future LAN listener keeps the HTML implementation below.
            if HOST in ("127.0.0.1", "::1", "localhost"):
                if self.client_address[0] not in ("127.0.0.1", "::1"):
                    self.send_error(403)
                    return
                try:
                    launch_gui("language-settings", APP_DIR / "language_settings.py")
                except OSError:
                    self.send_error(500, "Cannot launch language settings GUI")
                    return
                # Keep the current menu in place after launching the desktop GUI.
                self.send_response(204)
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                return
            language_settings.handle_get(self)
            return



        # -----------------------------------------------
        # アップデート確認
        # -----------------------------------------------

        if self.path == "/update-check":
            self.send_html(make_update_check_html())
            return


        # -----------------------------------------------
        # アップデート適用
        # -----------------------------------------------

        if self.path == "/update-apply":

            try:
                subprocess.Popen(
                    [
                        sys.executable,
                        str(UPDATE_APPLY)
                    ],
                    cwd=APP_DIR,
                    start_new_session=True
                )

            except Exception as e:
                self.send_html(
                    f"<h2>{t('portal_launch_error')}</h2>"
                    f"<pre>{e}</pre>"
                )
                return

            self.send_response(303)
            self.send_header("Location", "/update-check")
            self.end_headers()
            return


        # -----------------------------------------------
        # 終了
        # -----------------------------------------------

        if self.path == "/shutdown":

            try:
                stop_idle(exclude_pid=os.getpid())
            except (OSError, RuntimeError):
                self.send_html(f"<h2>{t('close_active_send')}</h2>")
                return

            self.send_html(
                f"""
                <html lang="{LANG}">
                <head>
                <meta charset="UTF-8">
                </head>
                <body>
                <h2>{t("portal_closed")}</h2>
                </body>
                </html>
                """
            )

            threading.Thread(
                target=self.server.shutdown,
                daemon=True
            ).start()

            return


        # -----------------------------------------------
        # 404
        # -----------------------------------------------

        self.send_error(404)


    def log_message(self, format, *args):
        # ターミナルへのHTTPアクセスログを抑制
        pass


# =========================================================
# 起動
# =========================================================

def main():

    server = ThreadingHTTPServer(
        (HOST, PORT),
        PortalHandler
    )

    print(
        f"{t('portal_running')}: "
        f"http://{HOST}:{PORT}"
    )

    try:
        server.serve_forever()

    except KeyboardInterrupt:
        pass

    finally:
        server.server_close()


if __name__ == "__main__":
    main()
