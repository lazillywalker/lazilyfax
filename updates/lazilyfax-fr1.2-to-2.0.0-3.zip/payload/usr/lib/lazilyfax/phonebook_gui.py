"""Native phonebook editor. User-visible strings live in the language catalogs."""

# Keep UI translations local; the installed engine and data remain unchanged.
import sys as _de_sys
from pathlib import Path as _DePath
_de_sys.path[:0] = [str(_DePath(__file__).resolve().parent), '/usr/lib/lazilyfax', '/usr/lib/lazilyfax/receive/app']
import language as _de_language
import translation_catalog as _de_catalog

from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from tkinter.scrolledtext import ScrolledText
from language import t
from paths import PHONEBOOK_DB
from phonebook_core import Phonebook,FIELDS,ContactError
from ui_theme import apply_theme,action_button

class PhonebookWindow:
    def __init__(self,root,path=PHONEBOOK_DB):
        self.root=root;self.store=Phonebook(path);self.original=None;self.loading=False
        self.entries={};self.selected_id=None
        apply_theme(root)
        style=ttk.Style(root)
        style.configure('Phonebook.TFrame',background='#FFFFFF')
        style.configure('Phonebook.TLabel',background='#FFFFFF',foreground='#334155')
        root.title('LazilyFAX - '+t('pb_title'))
        # Leave room for the desktop panel and window decorations on notebooks.
        width=max(640,min(1020,root.winfo_screenwidth()-80))
        height=max(420,min(620,root.winfo_screenheight()-120))
        root.geometry(f'{width}x{height}');root.minsize(min(860,width),min(520,height))
        outer=ttk.Frame(root,padding=(12,8),style='Phonebook.TFrame');outer.pack(fill='both',expand=True)
        outer.columnconfigure(0,weight=1);outer.rowconfigure(2,weight=1)
        ttk.Label(outer,style='Phonebook.TLabel',text=t('pb_title'),font=('Sans',16,'bold')).grid(row=0,column=0,sticky='w')
        search=ttk.Frame(outer,style='Phonebook.TFrame');search.grid(row=1,column=0,sticky='ew',pady=(6,4))
        ttk.Label(search,style='Phonebook.TLabel',text=t('pb_search')).pack(side='left')
        self.keyword=tk.StringVar()
        entry=ttk.Entry(search,textvariable=self.keyword);entry.pack(side='left',fill='x',expand=True,padx=8)
        entry.bind('<Return>',lambda event:self.refresh())
        ttk.Button(search,text=t('pb_search_button'),command=self.refresh).pack(side='left')
        table=ttk.Frame(outer,style='Phonebook.TFrame');table.grid(row=2,column=0,sticky='nsew')
        columns=('company','contact_person','fax','tel','mail')
        self.tree=ttk.Treeview(table,columns=columns,show='headings',selectmode='browse',height=6,style='LazilyFAX.Treeview')
        for key,width in zip(columns,(230,140,150,150,200)):
            self.tree.heading(key,text=t('pb_'+key));self.tree.column(key,width=width,minwidth=70)
        vertical=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview)
        horizontal=ttk.Scrollbar(table,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=vertical.set,xscrollcommand=horizontal.set)
        self.tree.grid(row=0,column=0,sticky='nsew');vertical.grid(row=0,column=1,sticky='ns');horizontal.grid(row=1,column=0,sticky='ew')
        table.rowconfigure(0,weight=1);table.columnconfigure(0,weight=1)
        self.tree.bind('<<TreeviewSelect>>',self.select)
        self.mode=tk.StringVar();ttk.Label(outer,style='Phonebook.TLabel',textvariable=self.mode,font=('Sans',11,'bold')).grid(row=3,column=0,sticky='w',pady=(6,2))
        form=ttk.Frame(outer,style='Phonebook.TFrame');form.grid(row=4,column=0,sticky='ew')
        for col in (1,3):form.columnconfigure(col,weight=1)
        for index,key in enumerate(FIELDS[:-1]):
            row=index//2;column=(index%2)*2
            ttk.Label(form,style='Phonebook.TLabel',text=t('pb_'+key)).grid(row=row,column=column,sticky='w',padx=(0,8),pady=2)
            var=tk.StringVar();self.entries[key]=var
            ttk.Entry(form,textvariable=var).grid(row=row,column=column+1,sticky='ew',padx=(0,16),pady=2)
        ttk.Label(form,style='Phonebook.TLabel',text=t('pb_notes')).grid(row=3,column=0,sticky='nw',pady=2)
        self.notes=ScrolledText(form,height=2,wrap='word',font=('Sans',10));self.notes.grid(row=3,column=1,columnspan=3,sticky='ew',padx=(0,16),pady=2)
        ttk.Label(outer,style='Phonebook.TLabel',text=t('pb_required_hint')).grid(row=5,column=0,sticky='w',pady=(2,4))
        actions=ttk.Frame(outer,style='Phonebook.TFrame');actions.grid(row=6,column=0,sticky='ew')
        self.buttons={}
        for key,command in [('new',self.new),('save',self.save),('delete',self.delete),('refresh',self.refresh),('close',self.close)]:
            button=tk.Button(actions,text=t('pb_'+key),command=command,padx=12,pady=5,cursor='hand2')
            if key in ('new','save','delete'):action_button(button,cancel=key=='delete')
            button.pack(side='right' if key=='close' else 'left',padx=(0,8));self.buttons[key]=button
        self.status=tk.StringVar();ttk.Label(outer,style='Phonebook.TLabel',textvariable=self.status).grid(row=7,column=0,sticky='w',pady=(4,0))
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.fill(None);self.reload()
    def error(self,error):
        key=str(error) if isinstance(error,ContactError) else 'pb_error'
        messagebox.showerror(t('pb_title'),t(key)+(('\n'+str(error)) if key=='pb_error' else ''),parent=self.root)
    def values(self):
        values={key:var.get() for key,var in self.entries.items()};values['notes']=self.notes.get('1.0','end-1c');return values
    def dirty(self):
        baseline={key:(self.original.get(key) or '') if self.original else '' for key in FIELDS}
        return self.values()!=baseline
    def discard(self):
        return not self.dirty() or messagebox.askyesno(t('pb_title'),t('pb_discard'),parent=self.root)
    def fill(self,record):
        self.original=record;self.selected_id=record['id'] if record else None
        for key,var in self.entries.items():var.set((record.get(key) or '') if record else '')
        self.notes.delete('1.0','end');self.notes.insert('1.0',(record.get('notes') or '') if record else '')
        self.mode.set(t('pb_edit') if record else t('pb_new'))
        self.buttons['delete'].configure(state='normal' if record else 'disabled')
    def reload(self,selected=None):
        self.loading=True
        try:
            rows=self.store.search(self.keyword.get().strip())
            self.tree.delete(*self.tree.get_children())
            for row in rows:self.tree.insert('', 'end',iid=str(row['id']),values=[row[k] or '' for k in ('company','contact_person','fax','tel','mail')])
            if selected is not None and self.tree.exists(str(selected)):
                self.tree.selection_set(str(selected));self.tree.see(str(selected))
            self.status.set(t('pb_count').format(count=len(rows)))
        finally:self.loading=False
    def select(self,event=None):
        if self.loading:return
        selected=self.tree.selection()
        if not selected:return
        identity=int(selected[0])
        if identity==self.selected_id:return
        if not self.discard():
            self.loading=True
            try:
                self.tree.selection_remove(*selected)
                if self.selected_id is not None and self.tree.exists(str(self.selected_id)):self.tree.selection_set(str(self.selected_id))
            finally:self.loading=False
            return
        try:
            record=self.store.get(identity)
            if record is None:raise ContactError('pb_conflict')
            self.fill(record)
        except Exception as error:self.error(error)
    def new(self):
        if self.discard():
            self.fill(None);self.tree.selection_remove(*self.tree.selection())
    def refresh(self):
        if not self.discard():return
        try:self.fill(None);self.reload()
        except Exception as error:self.error(error)
    def save(self):
        try:
            identity=self.store.save(self.values(),self.original)
            self.fill(self.store.get(identity));self.reload(identity)
            self.status.set(t('pb_saved'))
        except Exception as error:self.error(error)
    def delete(self):
        if self.original is None:return
        if not messagebox.askyesno(t('pb_title'),t('pb_confirm_delete').format(company=self.original['company']),parent=self.root):return
        try:self.store.delete(self.original);self.fill(None);self.reload();self.status.set(t('pb_deleted'))
        except Exception as error:self.error(error)
    def close(self):
        if self.discard():self.root.destroy()

def main():
    root=tk.Tk();root.withdraw()
    try:PhonebookWindow(root)
    except Exception as error:
        key=str(error) if isinstance(error,ContactError) else 'pb_error'
        messagebox.showerror(t('pb_title'),t(key)+(('\n'+str(error)) if key=='pb_error' else ''),parent=root);root.destroy();return
    root.deiconify();root.mainloop()

if __name__=='__main__':
    from maintenance import guard_start
    _maintenance_gate=guard_start()
    main()
