"""Native header editor using the existing validated format and renderer."""

# Keep UI translations local; the installed engine and data remain unchanged.
import sys as _de_sys
from pathlib import Path as _DePath
_de_sys.path[:0] = [str(_DePath(__file__).resolve().parent), '/usr/lib/lazilyfax', '/usr/lib/lazilyfax/receive/app']
import language as _de_language
import translation_catalog as _de_catalog

import io
import tkinter as tk
from tkinter import ttk,messagebox
from tkinter.scrolledtext import ScrolledText
from PIL import Image,ImageTk
import header_settings as core
import lifecycle
from language import t
from ui_theme import apply_theme,action_button

class HeaderWindow:
    def __init__(self,root):
        self.root=root;self.entries={};self.options={};self.image=None;self.photo=None;self.baseline={}
        apply_theme(root);style=ttk.Style(root)
        style.configure('Header.TFrame',background='#FFFFFF')
        style.configure('Header.TLabel',background='#FFFFFF',foreground='#334155')
        style.configure('Header.TCheckbutton',background='#FFFFFF',foreground='#334155')
        root.title('LazilyFAX - '+t('header_title'));
        width=max(640,min(960,root.winfo_screenwidth()-80))
        height=max(420,min(620,root.winfo_screenheight()-100))
        root.geometry(f'{width}x{height}');root.minsize(min(850,width),min(520,height))
        outer=ttk.Frame(root,padding=(12,8),style='Header.TFrame');outer.pack(fill='both',expand=True)
        outer.columnconfigure(0,weight=1);outer.rowconfigure(5,weight=1)
        ttk.Label(outer,text=t('header_title'),font=('Sans',16,'bold'),style='Header.TLabel').grid(row=0,column=0,sticky='w')
        ttk.Label(outer,text=t('header_intro'),wraplength=780,style='Header.TLabel').grid(row=1,column=0,sticky='w',pady=(4,6))
        form=ttk.Frame(outer,style='Header.TFrame');form.grid(row=2,column=0,sticky='ew');form.columnconfigure(1,weight=1)
        for row,key in enumerate(core.FIELDS):
            ttk.Label(form,text=t('header_'+key),style='Header.TLabel').grid(row=row,column=0,sticky='nw',padx=(0,12),pady=2)
            if key=='extra':
                self.extra=ScrolledText(form,height=2,wrap='word',font=('Sans',10));self.extra.grid(row=row,column=1,sticky='ew',padx=(0,12),pady=2)
            else:
                var=tk.StringVar();self.entries[key]=var
                ttk.Entry(form,textvariable=var).grid(row=row,column=1,sticky='ew',padx=(0,12),pady=2)
            option='print_'+key
            if option in core.OPTIONS:
                var=tk.BooleanVar();self.options[option]=var
                ttk.Checkbutton(form,text=t('header_print_optional'),variable=var,style='Header.TCheckbutton').grid(row=row,column=2,sticky='nw',pady=2)
        ttk.Label(outer,text=t('header_optional_help')+'\n'+t('header_help'),wraplength=780,style='Header.TLabel').grid(row=3,column=0,sticky='w',pady=(4,4))
        ttk.Label(outer,text=t('header_preview_title'),font=('Sans',11,'bold'),style='Header.TLabel').grid(row=4,column=0,sticky='w')
        self.canvas=tk.Canvas(outer,height=64,bg='#FFFFFF',highlightthickness=1,highlightbackground='#CBD5E1');self.canvas.grid(row=5,column=0,sticky='nsew',pady=4)
        self.canvas.bind('<Configure>',self.draw_preview)
        ttk.Label(outer,text=t('header_note'),wraplength=780,style='Header.TLabel').grid(row=6,column=0,sticky='w',pady=(0,4))
        actions=ttk.Frame(outer,style='Header.TFrame');actions.grid(row=7,column=0,sticky='ew')
        self.preview_button=ttk.Button(actions,text=t('header_preview'),command=self.preview);self.preview_button.pack(side='left')
        self.save_button=tk.Button(actions,text=t('header_save'),command=self.save,padx=20,pady=5,cursor='hand2');action_button(self.save_button);self.save_button.pack(side='left',padx=10)
        self.reload_button=ttk.Button(actions,text=t('header_reload'),command=self.reload);self.reload_button.pack(side='left')
        self.close_button=ttk.Button(actions,text=t('header_close'),command=self.close);self.close_button.pack(side='right')
        self.status=tk.StringVar();ttk.Label(outer,textvariable=self.status,wraplength=780,style='Header.TLabel').grid(row=8,column=0,sticky='w',pady=(4,0))
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.load(core.read_raw())
    def values(self):
        result={k:v.get() for k,v in self.entries.items()};result['extra']=self.extra.get('1.0','end-1c')
        result.update({k:v.get() for k,v in self.options.items()});return result
    def dirty(self):return self.values()!=self.baseline
    def discard(self):
        return not self.dirty() or messagebox.askyesno(t('header_title'),t('header_discard'),parent=self.root)
    def load(self,raw):
        values=core.parse(raw)[0]
        self.raw=raw;self.expected=core.digest(raw)
        for key,var in self.entries.items():var.set(values[key])
        self.extra.delete('1.0','end');self.extra.insert('1.0',values['extra'])
        for key,var in self.options.items():var.set(values[key])
        self.baseline=self.values();self.render(notify=False)
    def show_error(self,error):
        if isinstance(error,core.InvalidHeader):key=str(error)
        elif isinstance(error,core.Changed):key='conflict'
        elif isinstance(error,PermissionError):key='permission'
        else:key='error'
        self.status.set(t('header_'+key));messagebox.showerror(t('header_title'),t('header_'+key),parent=self.root)
    def draw_preview(self,event=None):
        self.canvas.delete('all')
        if self.image is None:
            self.canvas.create_text(12,12,text=self.status.get(),anchor='nw',width=max(100,self.canvas.winfo_width()-24),fill='#64748B');return
        scale=min(1,max(1,self.canvas.winfo_width()-16)/self.image.width,
                  max(1,self.canvas.winfo_height()-16)/self.image.height)
        width=max(1,round(self.image.width*scale));height=max(1,round(self.image.height*scale))
        self.photo=ImageTk.PhotoImage(self.image.resize((width,height),Image.Resampling.LANCZOS))
        self.canvas.create_image(8,max(8,(self.canvas.winfo_height()-height)//2),image=self.photo,anchor='nw')
    def render(self,notify=True):
        try:
            raw=core.serialize(self.raw,core.validate(self.values()))
            with Image.open(io.BytesIO(core.preview_png(raw))) as image:self.image=image.copy()
        except Exception as error:
            self.image=None
            if notify:self.show_error(error)
            else:self.status.set(t('header_'+str(error)) if isinstance(error,core.InvalidHeader) else t('header_read_error'))
            self.draw_preview();return False
        self.draw_preview();return True
    def preview(self):
        if self.render():self.status.set(t('header_draft'))
    def reload(self):
        if not self.discard():return
        try:self.load(core.read_raw());self.status.set('')
        except Exception as error:self.show_error(error)
    def save(self):
        fd=None;error=None
        try:
            # Compute the exact prospective bytes without changing the file.
            values=core.validate(self.values());updated=core.serialize(self.raw,values)
            fd=lifecycle.acquire_activity()
            core.save(values,self.expected)
        except Exception as exc:error=exc
        finally:lifecycle.release_activity(fd)
        if error is not None:
            if isinstance(error,BlockingIOError):
                self.status.set(t('header_busy'));messagebox.showinfo(t('header_title'),t('header_busy'),parent=self.root)
            else:self.show_error(error)
            return
        self.load(updated);self.status.set(t('header_saved'))
    def close(self):
        if self.discard():self.root.destroy()

def main():
    root=tk.Tk();root.withdraw()
    try:HeaderWindow(root)
    except Exception as error:
        messagebox.showerror(t('header_title'),t('header_read_error')+'\n'+str(error),parent=root);root.destroy();return
    root.deiconify();root.mainloop()

if __name__=='__main__':
    from maintenance import guard_start
    _maintenance_gate=guard_start()
    main()
