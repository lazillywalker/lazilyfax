# LazilyFAX Gumroad-Version: Registrierung und Updates

Anleitung für LazilyFAX 2.0.0, Gumroad-Version (Paket 2.0.0-19). Diese Ergänzung beschreibt Registrierung, Updates und die Sicherung der Registrierungsdaten zusätzlich zu den PDF-Handbüchern.

1. Öffnen Sie Ihre Gumroad-Kaufbestätigung oder den Kaufbeleg. Der Lizenzschlüssel ist Ihre Registrierungsnummer.
2. Öffnen Sie Einstellungen → Lizenzregistrierung.
3. Geben Sie die Kauf-E-Mail und den Schlüssel ein und wählen Sie Kauf prüfen und speichern.
4. Nach erfolgreicher Registrierung bleiben die Angaben auch nach einem Neustart gespeichert.

Der sample-Schlüssel im Produkteditor ist kein Kaufschlüssel. Testkaufschlüssel berechtigen nicht zu regulären Updates.

Bei der Update-Prüfung wird der Kaufstatus online überprüft. Der Schlüssel wird an Gumroad gesendet, die E-Mail wird lokal mit der Antwort verglichen. Ungültige, widerrufene oder erstattete Käufe berechtigen nicht zu Updates. Bei Verbindungsproblemen bleibt die Registrierung erhalten; versuchen Sie es später erneut. Ein passender Update-Pfad muss ebenfalls verfügbar sein.

FAX-Versand, Empfang und Anrufbeantworter werden durch diese Update-Lizenzprüfung nicht gesperrt. Beenden Sie FAX- und Anrufbeantworteraktivitäten vor einem Update.

Sichern Sie im Fenster zur Datensicherung sowohl die FAX-Daten (.lfaxbackup) als auch die Registrierung separat (.lfaxlicense). Die Registrierungsdatei enthält E-Mail und Schlüssel und ist nicht verschlüsselt. Bewahren Sie sie vertraulich auf. Daten außerhalb der bisherigen FAX-Sicherung, einschließlich Sprachnachrichten, müssen separat gesichert werden.

Vor dem Wiederherstellen bestätigen Sie das Ersetzen der aktuellen Registrierung. Eine erfolgreiche Wiederherstellung bestätigt nicht die Gültigkeit des Kaufs; beim Update wird erneut geprüft. Ungültige Dateien und Dateien anderer Produkte werden abgelehnt, ohne die vorhandene Registrierung zu ersetzen.

Bei Problemen wenden Sie sich über Einstellungen → Support an den Support und nennen Sie App-Version und Fehlermeldung. Veröffentlichen Sie niemals Ihren vollständigen Schlüssel.
