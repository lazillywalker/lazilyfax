# LazilyFAX Gumroad edition: registration and updates

Instructions for LazilyFAX 2.0.0 Gumroad edition (package 2.0.0-19). Use this supplement alongside the PDF manuals for registration, updates and registration backups.

1. Find your Gumroad license key on your purchase confirmation page or receipt. This is your registration number.
2. Open Settings → License registration.
3. Enter the purchase email and key, then choose Verify purchase and save.
4. A successful registration is saved across restarts.

The sample key in the seller's editor is not a purchase key. Test purchase keys cannot authorize production updates.

Open Settings → Check for updates to update. Purchase status is checked online. The key is sent to Gumroad; the email is compared locally with the response. Invalid, revoked or refunded purchases cannot authorize updates. A connection failure retains the saved registration; retry later. A compatible update route must also exist.

FAX sending, receiving and the answering machine are not gated by this update license check. Stop FAX and answering-machine activity before updating.

In Backup and Restore, save both the FAX data backup (.lfaxbackup) and the separate registration backup (.lfaxlicense). Registration backups contain your email and key and are not encrypted; keep them private. Back up data outside the existing FAX backup scope, including voicemail recordings, separately.

Restore registration separately asks before replacing the current registration. Restoration does not establish purchase validity: updates still verify online. Invalid or wrong-product backups are rejected without replacing existing registration.

For help, check the purchase email and key, then use Settings → Support. Report the app version and error message; do not post your full key publicly.
