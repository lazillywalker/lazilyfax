LazilyFAX 2.0.0 / Ubuntu 24.04+ based distributions / amd64; reference: Linux Mint 22.3
2026-11-10

日本語 — インストールと初回設定
1. 対応USB FAXモデムを接続し、電話回線をモデムのLINE端子へ接続します。留守番電話には音声機能も必要です。
2. 新規導入は購入したlazilyfax_2.0.0-19_amd64.debをダブルクリックし、管理者認証に従います。端末からはファイルのある場所で:
   sudo apt install ./lazilyfax_2.0.0-19_amd64.deb
   この配布物にinstall.shはありません。
3. 更新の場合は先に待受と通信を停止し、編集中の内容を保存してLazilyFAXの全画面・トレイを終了します。アプリのバックアップを別の場所に保存し、ホームのtelam/voicemailの録音も別途保存してください。旧版を先に削除する必要はありません。
4. メニューのLazilyFAXから起動します。初回のアクセス設定で管理者認証を求められた場合は案内に従い、ログアウト・再ログインして権限を反映します。
5. 表示言語、モデム、送信ヘッダーを設定します。会社名・FAX送信先・原稿プレビューを確認し、送信・受信を別々に試します。留守電は案内・録音・再生・次着信も確認してください。
6. マニュアルは設定言語に応じて開きます。日本語/英語/韓国語/ドイツ語とも第13章はバックアップ、第14章はアップデートです。削除方法はUNINSTALL.txtを参照。

English — Installation and first use
Install the purchased DEB with the package installer, or run the apt command above. No install.sh is included. Before upgrading, stop fax/answering-machine standby, save edits and close all windows/tray. Back up application data and copy ~/telam/voicemail separately. Do not uninstall the old version first. Launch LazilyFAX from the application menu. Follow administrator authentication for access setup, then log out and in if requested. Set language, modem and sender header; test sending, receiving and voicemail separately. Read manual_en.pdf; Chapter 13 covers backup, Chapter 14 updates. Removal: UNINSTALL.txt.

한국어 — 설치 및 첫 실행
구매한 DEB 파일을 패키지 설치 프로그램으로 설치하거나 위의 apt 명령을 실행하세요. install.sh는 포함되어 있지 않습니다. 업데이트 전 팩스·자동응답 대기를 중지하고 편집 내용을 저장한 뒤 모든 창과 트레이를 닫으세요. 프로그램 데이터를 백업하고 ~/telam/voicemail도 별도로 복사하세요. 기존 버전을 먼저 제거할 필요는 없습니다. 메뉴에서 LazilyFAX를 실행하고 권한 설정의 관리자 인증 안내에 따르세요. 필요하면 로그아웃 후 다시 로그인하세요. 언어·모뎀·발신자 머리글을 설정하고 송신·수신·자동응답을 각각 시험하세요. manual_ko.pdf의 13장은 백업, 14장은 업데이트입니다. 제거 방법은 UNINSTALL.txt를 참조하세요.

Deutsch — Installation und erster Start
Installieren Sie die gekaufte DEB-Datei mit der Paketverwaltung oder dem obigen apt-Befehl. install.sh ist nicht enthalten. Beenden Sie vor einem Update Fax- und Anrufbeantworterbereitschaft, speichern Sie Änderungen und schließen Sie alle Fenster und das Tray. Sichern Sie die Anwendungsdaten und ~/telam/voicemail separat. Entfernen Sie die alte Version nicht zuerst. Starten Sie LazilyFAX über das Anwendungsmenü und folgen Sie der Administratorauthentifizierung zur Zugriffsfreigabe. Melden Sie sich bei Aufforderung ab und wieder an. Stellen Sie Sprache, Modem und Absenderkopf ein; testen Sie Versand, Empfang und Anrufbeantworter getrennt. manual_de.pdf: Kapitel 13 Datensicherung, Kapitel 14 Updates. Entfernen: UNINSTALL.txt.

Update distribution / 更新配布
The complete application DEB is distributed to purchasers. GitHub contains update deltas and public guidance only. Availability is controlled by the published update catalog; this package does not imply that a 2.0.0-5 online update has already been activated. Current updates use official GitHub HTTPS and SHA256, not publisher signature verification.

Old voicemail launcher / 旧留守電ランチャー
Use /usr/bin/lazilyfax from the installed application menu. An old user-specific voicemail launcher may reject changed files; do not start the old extension and integrated application together. See FR1-release-notes.md for migration history.

Support / サポート
Open Settings > Support for purchaser contact details. Purchase-site inquiries are also available. Check the package version displayed there before sending a report. Do not post personal fax documents, phonebooks, recordings or license data in public GitHub Issues.

Current support scope: SUPPORT-SCOPE.txt / 対象OSと設定支援の範囲はSUPPORT-SCOPE.txtを参照。

販売版への更新 / Updating to the sale package
製品表示は2.0.0、Debian管理番号は2.0.0-19です。旧試作2.0.0-1〜9から通常の更新になります。
通信・待受・アプリを終了し、アプリデータと留守電録音を別々にバックアップしてから実行してください。
  sudo apt install ./lazilyfax_2.0.0-19_amd64.deb
Stop all application and modem activity; back up application data and voicemail recordings before installation. No downgrade option is needed.

Gumroad edition package version: 2.0.0-19. Read gumroad/ for registration, updates and registration backups. Historical release notes describe earlier versions.

Gumroad登録・更新 / Registration and updates / Registrierung und Updates / 등록 및 업데이트
gumroad/内の4言語補足手順を参照してください。FAXバックアップとは別に登録情報も保存してください。
See gumroad/ for the four-language supplement. Save registration separately from FAX backups.
Siehe gumroad/ für die Ergänzung in vier Sprachen. Registrierungsdaten separat sichern.
gumroad/의 4개 언어 보충 안내를 참조하세요. 등록 정보는 팩스 데이터와 별도로 백업하세요.
